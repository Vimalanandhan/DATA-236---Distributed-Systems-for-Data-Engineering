-- mysql -u root -p

CREATE DATABASE ubereats;
USE ubereats;


CREATE TABLE Customer (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    profile_picture MEDIUMBLOB, -- To store images as binary data
    country VARCHAR(100),
    state VARCHAR(100)
);

CREATE TABLE Restaurant (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    location VARCHAR(255),
    description TEXT,
    contact_info VARCHAR(100),
    image MEDIUMBLOB, -- To store images as binary data
    timings VARCHAR(100)
);

CREATE TABLE Dish (
    id INT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    ingredients TEXT,
    image MEDIUMBLOB, -- To store dish images
    price DECIMAL(10, 2) NOT NULL,
    description TEXT,
    category VARCHAR(50),
    FOREIGN KEY (restaurant_id) REFERENCES Restaurant(id)
);

CREATE TABLE OrderTable (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    restaurant_id INT NOT NULL,
    items JSON,
    status ENUM('New', 'Preparing', 'On the way', 'Delivered', 'Cancelled') NOT NULL DEFAULT 'New',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    delivery_address TEXT NOT NULL,
    total_amount decimal(10,2) NOT NULL DEFAULT NULL            
    FOREIGN KEY (customer_id) REFERENCES Customer(id),
    FOREIGN KEY (restaurant_id) REFERENCES Restaurant(id)
);

CREATE TABLE Favorites (
    customer_id INT NOT NULL,
    restaurant_id INT NOT NULL,
    PRIMARY KEY (customer_id, restaurant_id),
    FOREIGN KEY (customer_id) REFERENCES Customer(id),
    FOREIGN KEY (restaurant_id) REFERENCES Restaurant(id)
);



INSERT INTO Customer (name, email, password, profile_picture, country, state)
VALUES 
('John Doe', 'john@example.com', 'password123', NULL, 'USA', 'California'),
('Jane Smith', 'jane@example.com', 'password456', NULL, 'Canada', 'Ontario'),
('Michael Brown', 'michael@example.com', 'password789', NULL, 'UK', 'London');

INSERT INTO Restaurant (name, email, password, location, description, contact_info, images, timings)
VALUES 
('Pizza Palace', 'pizza@example.com', 'securepassword', '123 Main St, New York, NY', 'Best pizza in town!', '123-456-7890', NULL, '10:00 AM - 10:00 PM'),
('Burger Barn', 'burger@example.com', 'burgerlove123', '456 Elm St, Los Angeles, CA', 'Delicious gourmet burgers.', '987-654-3210', NULL, '11:00 AM - 11:00 PM'),
('Sushi Spot', 'sushi@example.com', 'sushi123', '789 Oak Ave, San Francisco, CA', 'Fresh sushi and sashimi.', '555-555-5555', NULL, '11:30 AM - 10:30 PM');

INSERT INTO Dish (restaurant_id, name, ingredients, image, price, description, category)
VALUES 
(1, 'Margherita Pizza', 'Tomato, Mozzarella, Basil', NULL, 12.99, 'Classic Italian pizza with fresh ingredients.', 'Main Course'),
(1, 'Pepperoni Pizza', 'Tomato, Mozzarella, Pepperoni', NULL, 14.99, 'Spicy and flavorful pepperoni pizza.', 'Main Course'),
(2, 'Classic Cheeseburger', 'Beef Patty, Cheddar Cheese, Lettuce, Tomato', NULL, 10.99, 'Juicy beef burger with all the classic toppings.', 'Main Course'),
(2, 'Veggie Burger', 'Veggie Patty, Lettuce, Tomato, Onion', NULL, 9.99, 'Healthy and delicious veggie burger.', 'Main Course'),
(3, 'California Roll', 'Crab, Avocado, Cucumber', NULL, 8.99, 'Popular sushi roll with fresh ingredients.', 'Appetizer'),
(3, 'Spicy Tuna Roll', 'Tuna, Spicy Mayo, Cucumber', NULL, 9.99, 'Spicy tuna roll with a kick.', 'Appetizer');

INSERT INTO OrderTable (customer_id, restaurant_id, items, status, delivery_address)
VALUES 
(1, 1, '[{"dish_id": 1, "quantity": 2}, {"dish_id": 2, "quantity": 1}]', 'New', '456 Elm St, Los Angeles, CA'),
(2, 2, '[{"dish_id": 3, "quantity": 1}, {"dish_id": 4, "quantity": 1}]', 'Preparing', '789 Pine St, Toronto, ON'),
(3, 3, '[{"dish_id": 5, "quantity": 2}, {"dish_id": 6, "quantity": 1}]', 'Delivered', '101 Maple St, London, UK');

INSERT INTO Favorites (customer_id, restaurant_id)
VALUES 
(1, 1),
(1, 3),
(2, 2),
(3, 1),
(3, 3);


select * from Customer;