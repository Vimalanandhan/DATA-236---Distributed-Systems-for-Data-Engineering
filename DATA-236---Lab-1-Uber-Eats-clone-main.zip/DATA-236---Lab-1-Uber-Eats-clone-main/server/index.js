require('dotenv').config();
const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const mongoose = require('mongoose');
const { connectDB } = require('./config/db');
const apiRoutes = require('./routes/api');
const { connectProducer } = require('./kafka/client');

const app = express();
const port = process.env.PORT || 5001;

// CORS configuration
app.use(cors({
  origin: true, // Allow all origins
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['Set-Cookie']
}));

// Body parser
app.use(express.json());

// Cookie parser
app.use(cookieParser());

// Session middleware
app.use(session({
  name: 'connect.sid',
  secret: process.env.SESSION_SECRET || 'uber-eats-secret',
  resave: false,
  saveUninitialized: false,
  rolling: true,
  store: MongoStore.create({
    clientPromise: connectDB().then(conn => conn.getClient()),
    ttl: 24 * 60 * 60,
  }),
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: process.env.NODE_ENV === 'production' ? 'none' : 'lax',
    path: '/',
    maxAge: 24 * 60 * 60 * 1000
  }
}));

// Debug middleware
app.use((req, res, next) => {
  console.log('Cookies:', req.cookies);
  next();
});

// Routes
app.use('/api', apiRoutes);

// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start server
const startServer = async () => {
  try {
    await connectDB();
    await connectProducer();

    app.listen(port, () => {
      console.log(`Server running on http://localhost:${port}`);
    });
  } catch (err) {
    console.error('Error starting server:', err);
    process.exit(1);
  }
};

startServer();

module.exports = app;
