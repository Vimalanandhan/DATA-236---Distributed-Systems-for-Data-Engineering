const express = require('express');
const router = express.Router();
const multer = require('multer');
const apiController = require('../controllers/apiController');
const { checkRestaurantAuth } = require('../middleware/checkRestaurantAuth');
const checkCustomerAuth = require('../middleware/checkCustomerAuth');


// Multer Configuration (unchanged)
const storage = multer.memoryStorage();
const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        console.log('fileFilter called');
        if (!file) {
            console.log('No file provided');
            return cb(null, true);
        }
        console.log('File mimetype:', file.mimetype);
        if (file.mimetype.startsWith('image/')) {
            console.log('File is an image');
            cb(null, true);
        } else {
            console.log('File is not an image');
            cb(new Error('Only image files are allowed'));
        }
    }
});

// Helper function to handle async routes with error handling
const asyncHandler = (fn) => (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
};


// Customer Auth & Profile (unchanged)
router.post('/auth/customer/signup', apiController.customerSignup);
router.post('/auth/customer/login', apiController.customerLogin);
router.post('/auth/customer/logout', apiController.customerLogout);
router.get('/auth/customer/me', checkCustomerAuth, apiController.getCurrentCustomer);
router.get('/customers/:id', apiController.getCustomerById); //or similar
router.put('/customers', checkCustomerAuth, apiController.updateCustomer); // Correctly call updateCustomer
router.put('/customers/profile', checkCustomerAuth, upload.single('profile_picture'), apiController.updateCustomerProfile);
router.get('/customers/profile', checkCustomerAuth, apiController.getCustomerProfile);


// Restaurant Auth & Profile (unchanged)
router.post('/auth/restaurant/signup', apiController.restaurantSignup);
router.post('/auth/restaurant/login', apiController.restaurantLogin);
router.post('/auth/restaurant/logout', apiController.restaurantLogout);
router.get('/auth/restaurant/me', checkRestaurantAuth, asyncHandler(apiController.getRestaurantProfile));


// Restaurant Profile (Protected)
router.get('/restaurants/profile', checkRestaurantAuth, asyncHandler(apiController.getRestaurantProfile));
router.put('/restaurants/profile', checkRestaurantAuth, (req, res, next) => {
    console.log('Received profile update request:', req.body);
    upload.single('image')(req, res, (err) => {
        if (err) {
            console.error('Multer error:', err);
            return res.status(500).json({ error: 'Image upload failed', details: err.message });
        }
        apiController.updateRestaurantProfile(req, res, next);
    });
});
router.get('/restaurants/dishes', checkRestaurantAuth, asyncHandler(apiController.getRestaurantDishes));


// Dish Management (Protected)
router.post('/dishes', checkRestaurantAuth, upload.single('image'), asyncHandler(apiController.createDish));
router.put('/dishes/:id', checkRestaurantAuth, upload.single('image'), asyncHandler(apiController.updateDish));
router.delete('/dishes/:id', checkRestaurantAuth, asyncHandler(apiController.deleteDish)); // Added delete route


// Public Routes - Improved Error Handling
router.get('/restaurants', asyncHandler(apiController.getRestaurants));
router.get('/restaurants/:id', asyncHandler(apiController.getRestaurantById));
router.get('/restaurants/:id/menu', asyncHandler(apiController.getRestaurantMenu)); // Added menu route
router.get('/dishes/:id', asyncHandler(apiController.getDishById));


// Orders (unchanged)
router.get('/orders/customer/:customerId', apiController.getOrdersByCustomerId);
router.get('/orders', checkRestaurantAuth, asyncHandler(apiController.getOrders));
router.get('/orders/:id', apiController.getOrderById);
router.post('/orders', apiController.createOrder);
router.put('/orders/:id', checkRestaurantAuth, apiController.updateOrder);
router.put('/orders/:id/cancel', checkCustomerAuth, apiController.cancelOrder);


// Favorites - Improved Error Handling and Security
router.get('/api/customers/favorites', checkCustomerAuth, asyncHandler(apiController.getFavorites));
router.post('/api/customers/favorites', checkCustomerAuth, asyncHandler(apiController.createFavorite));
router.delete('/api/customers/favorites/:restaurant_id', checkCustomerAuth, asyncHandler(apiController.deleteFavorite));

// --- Favorites API Routes --- 
router.get('/favorites', checkCustomerAuth, asyncHandler(apiController.getFavorites));
router.post('/favorites', checkCustomerAuth, asyncHandler(apiController.addFavorite));
router.delete('/favorites/:restaurant_id', checkCustomerAuth, asyncHandler(apiController.removeFavorite));
// ---------------------------

// ... other routes ...


module.exports = router;
