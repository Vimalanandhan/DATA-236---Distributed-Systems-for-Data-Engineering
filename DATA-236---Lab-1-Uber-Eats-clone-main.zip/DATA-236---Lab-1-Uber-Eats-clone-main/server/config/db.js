require('dotenv').config();
const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/ubereats';

    // Check if already connecting or connected
    if (mongoose.connection.readyState === 1 || mongoose.connection.readyState === 2) {
      console.log('MongoDB already connected or connecting.');
      return mongoose.connection;
    }

    console.log('Connecting to MongoDB...');
    await mongoose.connect(mongoURI, {
      // useNewUrlParser: true, // Deprecated
      // useUnifiedTopology: true, // Deprecated
      serverSelectionTimeoutMS: 15000, // Increase timeout slightly
      socketTimeoutMS: 45000,
    });
    console.log('MongoDB connected successfully');
    return mongoose.connection;
  } catch (err) {
    console.error('MongoDB connection error:', err.message);
    // Don't exit the process here, let the caller handle it
    throw err;
  }
};

// Export the function to be called explicitly
module.exports = { connectDB };