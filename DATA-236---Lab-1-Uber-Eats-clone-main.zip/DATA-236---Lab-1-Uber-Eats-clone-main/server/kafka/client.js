const { Kafka, logLevel, Partitioners, AssignerProtocol } = require('kafkajs');

const KAFKA_BROKERS = [process.env.KAFKA_BROKER]; // Use the exposed port for host access
const CLIENT_ID = 'uber-eats-backend';

const isRetryableError = (error) => {
    // Add specific error codes that should be retried
    return (
        error.message.includes('The group coordinator is not available') ||
        error.message.includes('Not leader for partition') ||
        error.message.includes('There is no leader for this topic-partition') ||
        error.message.includes('Request timed out') ||
        error.code === 'ECONNREFUSED' // Network error
    );
};

const kafka = new Kafka({
    clientId: CLIENT_ID,
    brokers: KAFKA_BROKERS,
    logLevel: logLevel.INFO, // Keep INFO for now to see retries
    connectionTimeout: 5000, // Increased connection timeout
    requestTimeout: 30000,    // Increased request timeout
    retry: {
        initialRetryTime: 500, // Start retries a bit later
        retries: 10,           // Increase max retries
        maxRetryTime: 60000,   // Max time spent retrying 
        factor: 2,             // Exponential backoff factor
        multiplier: 1.5,       // Multiplier for backoff
        restartOnFailure: async (error) => {
            console.warn(`Kafka client connection failed: ${error.message}. Retrying...`);
            return isRetryableError(error); // Only retry specific errors
        },
    },
});

// Shared producer instance primarily for the main API server
const sharedProducer = kafka.producer({
    idempotent: true, // Enable idempotence for producer
    maxInFlightRequests: 1, // Ensure ordering for idempotent producer
    retry: { retries: 5 }, // Producer specific retry (less than client)
    // createPartitioner: Partitioners.DefaultPartitioner // Explicitly use default if needed
});

// Function to create a new producer instance (e.g., for consumers that also produce)
const createProducer = () => {
    return kafka.producer({
        idempotent: true,
        maxInFlightRequests: 1,
        retry: { retries: 5 },
        // createPartitioner: Partitioners.DefaultPartitioner 
    });
};

// Export the factory function for creating consumers
const createConsumerFunc = (config) => {
    // Add retry for consumer coordinator issues
    const consumerConfig = {
        ...config,
        retry: {
            initialRetryTime: 500,
            retries: 10,
            restartOnFailure: async (error) => isRetryableError(error)
        },
        // Optional: Adjust session timeout if needed
        // sessionTimeout: 45000, 
        // rebalanceTimeout: 70000, 
    };
    return kafka.consumer(consumerConfig);
};

// Connects the SHARED producer
const connectProducer = async () => {
    try {
        await sharedProducer.connect();
        console.log('Kafka Shared Producer connected');
    } catch (error) {
        console.error('Failed to connect Kafka Shared Producer:', error);
        process.exit(1);
    }
};

// Creates and connects a NEW producer instance
const createAndConnectProducer = async () => {
    const newProducer = createProducer();
    try {
        await newProducer.connect();
        console.log('Kafka New Producer connected');
        return newProducer;
    } catch (error) {
        console.error('Failed to connect Kafka New Producer:', error);
        throw error; // Re-throw error for the caller to handle
    }
};

// Disconnects a producer instance (defaults to shared producer)
const disconnectProducer = async (producerToDisconnect = sharedProducer) => {
    if (!producerToDisconnect) return;
    try {
        await producerToDisconnect.disconnect();
        console.log('Kafka Producer disconnected successfully');
    } catch (error) {
        console.error('Failed to disconnect Kafka Producer:', error);
    }
};

// Sends message using a SPECIFIC producer instance
const sendMessage = async (producerInstance, topic, messages) => {
    if (!producerInstance) {
        throw new Error('sendMessage requires a valid producerInstance.');
    }
    try {
        await producerInstance.send({
            topic,
            messages, // messages should be an array: [{ key: '...', value: '...' }]
        });
        // console.log(`Message sent successfully to topic ${topic}`); // Reduce noise
    } catch (error) {
        console.error(`Error sending message to topic ${topic}:`, error);
        // Re-throw error for caller handling if needed
        // throw error; 
    }
};

// Graceful shutdown for the SHARED producer only
const shutdownSharedProducer = async () => {
    console.log('Disconnecting Kafka Shared Producer...');
    await disconnectProducer(sharedProducer);
};

process.on('SIGINT', async () => {
    console.log('Received SIGINT.');
    await shutdownSharedProducer();
    process.exit(0);
});

process.on('SIGTERM', async () => {
    console.log('Received SIGTERM.');
    await shutdownSharedProducer();
    process.exit(0);
});

module.exports = {
    kafka,
    producer: sharedProducer, // Export shared producer (mainly for main app)
    consumer: createConsumerFunc, // Export the new factory function
    connectProducer,          // Connects the shared producer
    disconnectProducer,       // Disconnects a specific producer (defaults to shared)
    sendMessage,              // Sends message using a specific producer
    createAndConnectProducer, // Creates and connects a new producer
    KAFKA_TOPIC_ORDER_CREATED: 'order_created',
    KAFKA_TOPIC_ORDER_STATUS_UPDATE: 'order_status_update',
}; 