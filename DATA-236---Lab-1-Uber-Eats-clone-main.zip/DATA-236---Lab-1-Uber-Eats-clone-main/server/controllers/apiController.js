const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const OrderTable = require('../models/OrderTable');
const Customer = require('../models/Customer');
const Restaurant = require('../models/Restaurant');
const Dish = require('../models/Dish');
const Favorite = require('../models/Favorite');
const jwt = require('jsonwebtoken');
const { producer, sendMessage, KAFKA_TOPIC_ORDER_CREATED, KAFKA_TOPIC_ORDER_STATUS_UPDATE } = require('../kafka/client'); // Import shared producer

// Customer Endpoints
exports.getCustomers = async (req, res) => {
  try {
    const customers = await Customer.find();
    res.status(200).json(customers);
  } catch (err) {
    console.error('Error fetching customers:', err);
    res.status(500).json({ error: 'Failed to fetch customers' });
  }
};

exports.getCustomerById = async (req, res) => {
  const { id } = req.params;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ error: 'Invalid customer ID' });
  }

  try {
    // Explicitly select the profile_picture field
    const customer = await Customer.findById(id).select('+profile_picture');

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    let finalProfilePicture = null; // Variable to hold the final picture value
    // Check the raw Mongoose document field *before* toObject()
    // Force conversion attempt if the field exists, assuming it's buffer-like
    if (customer.profile_picture && typeof customer.profile_picture.toString === 'function') {
      try {
        // Assuming JPEG format, adjust if needed (e.g., image/png)
        finalProfilePicture = `data:image/jpeg;base64,${customer.profile_picture.toString('base64')}`;
      } catch (conversionError) {
        // Log error if conversion fails, but don't crash
        console.error('Error converting profile picture to Base64:', conversionError);
        finalProfilePicture = null; // Set to null if conversion fails
      }
    } else {
      // Ensure it's null if not convertible
      finalProfilePicture = null;
    }

    // Now convert the rest of the document to a plain object
    let customerData = customer.toObject();
    // Assign the processed profile picture value
    customerData.profile_picture = finalProfilePicture;

    // Removed debug log before sending
    res.status(200).json(customerData); // Send the modified data
  } catch (err) {
    console.error('Error fetching customer by ID:', err); // Updated error message
    res.status(500).json({ error: 'Failed to fetch customer' });
  }
};

exports.createCustomer = async (req, res) => {
  const { name, email, password, profile_picture, country, state } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const newCustomer = new Customer({
    name,
    email,
    password: hashedPassword,
    profile_picture,
    country,
    state
  });

  const savedCustomer = await newCustomer.save();
  res.status(201).json({ message: 'Customer created successfully', id: savedCustomer._id });
};

// Authentication Endpoints
exports.customerSignup = async (req, res) => {
  const { name, email, password, profile_picture, country, state } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    // Check if email already exists
    const existingCustomer = await Customer.findOne({ email });
    if (existingCustomer) {
      return res.status(400).json({ error: 'Email already exists' });
    }

    // Create new customer
    const newCustomer = new Customer({
      name,
      email,
      password: hashedPassword,
      profile_picture,
      country,
      state
    });

    const savedCustomer = await newCustomer.save();
    res.status(201).json({ message: 'Customer created successfully', id: savedCustomer._id });
  } catch (err) {
    console.error('Error creating customer:', err);
    return res.status(500).json({ error: 'Failed to create customer' });
  }
};

exports.customerLogin = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const customer = await Customer.findOne({ email });

    if (!customer) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, customer.password);

    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        id: customer._id,
        email: customer.email,
        isCustomer: true
      },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );

    // Set token in HTTP-only cookie
    res.cookie('customer_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    });

    res.status(200).json({
      message: 'Login successful',
      id: customer._id,
      name: customer.name,
      email: customer.email,
      token: token
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
};

exports.customerLogout = async (req, res) => {
  res.clearCookie('customer_token', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict'
  });
  res.json({ message: 'Logged out successfully' });
};

exports.getCurrentCustomer = async (req, res) => {
  if (!req.session.customerId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  try {
    const customer = await Customer.findById(req.session.customerId);
    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    res.status(200).json(customer);
  } catch (err) {
    console.error('Error fetching current customer:', err);
    res.status(500).json({ error: 'Failed to fetch current customer' });
  }
};

exports.updateCustomer = async (req, res) => {
  try {
    console.log("Session Customer ID:", req.session.customerId);
    const customerId = req.session.customerId;
    const { name, email, country, state } = req.body;

    if (!mongoose.Types.ObjectId.isValid(customerId)) {
      return res.status(400).json({ error: 'Invalid customer ID' });
    }

    const customer = await Customer.findById(customerId);

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    if (!name && !email && !country && !state) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    if (name) customer.name = name;
    if (email) customer.email = email;
    if (country) customer.country = country;
    if (state) customer.state = state;

    await customer.save();
    res.status(200).json({ message: 'Customer updated successfully' });
  } catch (error) {
    console.error('Error updating customer:', error);
    res.status(500).json({ error: 'Failed to update customer' });
  }
};

// Profile Management Endpoints
exports.updateCustomerProfile = async (req, res) => {
  try {
    // Use customer ID from authenticated user (JWT)
    const customerId = req.user?.id;

    if (!customerId) {
      // This case should ideally be caught by checkCustomerAuth, but double-check
      console.error('No customer ID found in req.user after authentication.');
      return res.status(401).json({ error: 'Authentication failed: User ID missing.' });
    }

    if (!mongoose.Types.ObjectId.isValid(customerId)) {
      console.error('Invalid customer ID format found in token:', customerId);
      return res.status(400).json({ error: 'Invalid customer ID' });
    }

    const customer = await Customer.findById(customerId);

    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    const { name, email, country, state } = req.body;
    const profile_picture = req.file ? req.file.buffer : null;

    if (!name && !email && !country && !state && !profile_picture) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    if (name) customer.name = name;
    if (email) customer.email = email;
    if (country) customer.country = country;
    if (state) customer.state = state;
    if (profile_picture) customer.profile_picture = profile_picture;

    await customer.save();

    // Convert picture to Base64 for the response, checking raw field first
    let finalProfilePicture = null;
    // Check the raw Mongoose document field *before* toObject()
    if (customer.profile_picture && typeof customer.profile_picture.toString === 'function') {
      try {
        // Assuming JPEG format
        finalProfilePicture = `data:image/jpeg;base64,${customer.profile_picture.toString('base64')}`;
      } catch (conversionError) {
        console.error('Error converting profile picture to Base64 in update response:', conversionError);
        finalProfilePicture = null;
      }
    } else {
      finalProfilePicture = null;
    }

    // Now convert the rest of the document to a plain object
    let responseCustomer = customer.toObject();
    // Assign the processed profile picture value
    responseCustomer.profile_picture = finalProfilePicture;
    delete responseCustomer.password; // Ensure password hash isn't sent back

    res.status(200).json({ message: 'Profile updated successfully', customer: responseCustomer });
  } catch (err) {
    // Log the full error for detailed debugging
    console.error('Detailed profile update error:', err);

    // Check for specific MongoDB duplicate key error (code 11000) for email
    if (err.code === 11000 && err.keyPattern && err.keyPattern.email) {
      return res.status(400).json({ error: 'Email address already in use.' });
    }

    // Generic error response
    res.status(500).json({ error: 'Failed to update profile. Please check server logs for details.' });
  }
};

exports.getCustomerProfile = async (req, res) => {
  // Reverted: Removed debug logs and Base64 conversion logic.
  // This endpoint fetches profile based on session.
  if (!req.session.customerId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  try {
    // Reverted: Removed .select('+profile_picture')
    const customer = await Customer.findById(req.session.customerId);
    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }
    // Note: This endpoint currently sends raw customer data, including potential Buffer for profile_picture.
    // If this endpoint is used elsewhere, it might need its own Base64 conversion.
    res.status(200).json(customer);
  } catch (err) {
    console.error('Error fetching customer profile:', err);
    res.status(500).json({ error: 'Failed to fetch customer profile' });
  }
};

// Restaurant Endpoints

// Add restaurant login handler
exports.restaurantLogin = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const restaurant = await Restaurant.findOne({ email });

    if (!restaurant) {
      console.log('Restaurant not found');
      return res.status(401).json({ error: 'Restaurant not found' });
    }

    const validPassword = await bcrypt.compare(password, restaurant.password);

    if (!validPassword) {
      console.log('Invalid password');
      return res.status(401).json({ error: 'Incorrect password' });
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        id: restaurant._id,
        email: restaurant.email,
        isRestaurant: true
      },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );

    // Set token in HTTP-only cookie
    res.cookie('restaurant_token', token, {
      httpOnly: true,
      secure: false,
      sameSite: 'none',
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    });

    res.status(200).json({
      message: 'Login successful',
      id: restaurant._id,
      name: restaurant.name,
      email: restaurant.email,
      token: token
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
};


exports.updateRestaurantProfile = async (req, res) => {
  console.log('updateRestaurantProfile called');
  try {
    const restaurantId = req.restaurant.id;
    const { name, email, location, cuisine, description, contact_info, timings } = req.body;
    const image = req.file ? req.file.buffer : null;

    console.log('Request body:', req.body);
    console.log('Uploaded image:', image);

    const restaurant = await Restaurant.findById(restaurantId);

    if (!restaurant) {
      console.log('Restaurant not found with ID:', restaurantId);
      return res.status(404).json({ error: 'Restaurant not found' });
    }

    console.log('Restaurant found:', restaurant);

    if (name) restaurant.name = name;
    if (email) restaurant.email = email;
    if (location) restaurant.location = location;
    if (cuisine) restaurant.cuisine = cuisine;
    if (description) restaurant.description = description;
    if (contact_info) restaurant.contact_info = contact_info;
    if (timings) restaurant.timings = timings;
    if (image) restaurant.image = image;

    console.log('Restaurant object before save:', restaurant);
    await restaurant.save();
    console.log('Restaurant profile updated successfully');
    const restaurantWithImage = {
      ...restaurant.toObject(),
      image: restaurant.image ? `data:image/jpeg;base64,${restaurant.image.toString('base64')}` : null
    };
    res.status(200).json(restaurantWithImage);
  } catch (error) {
    console.error('Error updating restaurant profile:', error);
    res.status(500).json({ error: 'Failed to update restaurant profile' });
  }
};
exports.getRestaurantProfile = async (req, res) => {
  try {
    const restaurant = await Restaurant.findById(req.restaurant.id);
    if (!restaurant) {
      return res.status(404).json({ error: 'Restaurant not found' });
    }
    const restaurantWithImage = {
      ...restaurant.toObject(),
      image: restaurant.image ? restaurant.image.toString('base64') : null,
    };
    res.status(200).json(restaurantWithImage);
  } catch (err) {
    console.error('Error fetching restaurant profile:', err);
    res.status(500).json({ error: 'Failed to fetch restaurant profile' });
  }
};

exports.getRestaurants = async (req, res) => {
  try {
    const restaurants = await Restaurant.find();
    const restaurantsWithImages = restaurants.map(restaurant => ({
      ...restaurant.toObject(),
      image: restaurant.image ? restaurant.image.toString('base64') : null
    }));
    res.status(200).json(restaurantsWithImages);
  } catch (err) {
    console.error('Error fetching restaurants:', err);
    res.status(500).json({ error: 'Failed to fetch restaurants' });
  }
};

console.log("getRestaurantProfile called");
exports.getRestaurantDishes = async (req, res) => {
  try {
    const restaurantId = req.restaurant.id;
    if (!restaurantId) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    // Use Mongoose to find dishes for the restaurant
    const dishes = await Dish.find({ restaurant_id: restaurantId });

    if (!dishes) {
      return res.json([]);
    }

    // Format dishes and handle images
    const formattedDishes = dishes.map(dish => ({
      id: dish._id,
      restaurant_id: dish.restaurant_id,
      name: dish.name,
      description: dish.description,
      price: dish.price,
      category: dish.category,
      ingredients: dish.ingredients,
      image: dish.image ? dish.image.toString('base64') : null
    }));

    res.json(formattedDishes);

  } catch (err) {
    console.error('Get dishes error:', err);
    res.status(500).json({
      error: 'Failed to fetch dishes',
      details: err.message
    });
  }
};

exports.getRestaurantById = async (req, res) => {
  try {
    const restaurant = await Restaurant.findById(req.params.id);
    if (!restaurant) {
      return res.status(404).json({ message: 'Restaurant not found' });
    }
    res.json(restaurant);
  } catch (error) {
    console.error('Error fetching restaurant:', error);
    res.status(500).json({ message: 'Failed to fetch restaurant', error: error.message });
  }
};

exports.getRestaurantMenu = async (req, res) => {
  try {
    const restaurantId = req.params.id;
    const menu = await Dish.find({ restaurant_id: restaurantId });

    if (!menu) {
      return res.status(404).json({ message: 'Menu not found for this restaurant' });
    }

    // Convert image to base64 and return as object
    const formattedMenu = menu.map(dish => ({
      id: dish._id,
      restaurant_id: dish.restaurant_id,
      name: dish.name,
      ingredients: dish.ingredients,
      price: dish.price,
      description: dish.description,
      category: dish.category,
      image: dish.image ? dish.image.toString('base64') : null, // Convert to base64
    }));

    res.json(formattedMenu);
  } catch (error) {
    console.error('Error fetching menu:', error);
    res.status(500).json({ message: 'Failed to fetch menu', error: error.message });
  }
};

exports.restaurantSignup = async (req, res) => {
  const { name, email, password, location, description, contact_info, timings, cuisine } = req.body;

  try {
    // Check if email already exists
    const existingRestaurant = await Restaurant.findOne({ email });
    if (existingRestaurant) {
      return res.status(400).json({ error: 'Email already exists' });
    }

    // Create new restaurant
    const newRestaurant = new Restaurant({
      name,
      email,
      password: hashedPassword,
      location,
      cuisine,
      description,
      contact_info,
      timings,
      cuisine
    });

    const savedRestaurant = await newRestaurant.save();

    // Generate JWT token
    const token = jwt.sign(
      {
        id: savedRestaurant._id,
        email: savedRestaurant.email,
        isRestaurant: true
      },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );

    // Set token in HTTP-only cookie
    res.cookie('restaurant_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    });

    res.status(201).json({ message: 'Restaurant created successfully', id: savedRestaurant._id });
  } catch (err) {
    console.error('Error creating restaurant:', err);
    // Provide more specific error if it's a validation error
    if (err.name === 'ValidationError') {
      return res.status(400).json({ error: 'Validation failed', details: err.message });
    }
    // Generic internal server error for other issues
    res.status(500).json({ error: 'Failed to create restaurant' });
  }
};

exports.restaurantLogout = async (req, res) => {
  res.clearCookie('restaurant_token', {
    httpOnly: true,
    secure: false,
    sameSite: 'none'
  });
  console.log('Attempted to clear restaurant_token cookie with options: { httpOnly: true, secure: false, sameSite: \'none\' }');
  res.json({ message: 'Logged out successfully' });
};

// Dish Endpoints
exports.getDishes = async (req, res) => {
  try {
    const dishes = await Dish.find();
    res.json(dishes);
  } catch (error) {
    console.error('Error fetching dishes:', error);
    res.status(500).json({ error: 'Failed to fetch dishes' });
  }
};

exports.getDishById = async (req, res) => {
  try {
    const { id } = req.params;
    const dish = await Dish.findById(id);
    if (!dish) {
      return res.status(404).json({ error: 'Dish not found' });
    }
    res.json(dish);
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ error: 'Failed to fetch dish' });
  }
};

exports.createDish = async (req, res) => {
  const { name, description, price, category, ingredients } = req.body;
  const image = req.file;

  // Validate required fields
  if (!name || !description || !price) {
    return res.status(400).json({ error: 'Name, description and price are required' });
  }

  try {
    const newDish = new Dish({
      restaurant_id: req.restaurant.id,
      name,
      description,
      price,
      category,
      ingredients,
      image: image ? image.buffer : null
    });

    const savedDish = await newDish.save();
    res.status(201).json({ message: 'Dish created successfully', dish: savedDish });
  } catch (err) {
    console.error('Error creating dish:', err);
    res.status(500).json({ error: 'Failed to create dish' });
  }
};

exports.updateDish = async (req, res) => {
  try {
    // --- FIX: Use req.restaurant from middleware --- 
    const restaurantId = req.restaurant?.id; // Get ID from JWT payload attached by middleware

    if (!restaurantId) {
      // This should technically not be hit if checkRestaurantAuth middleware ran correctly
      console.error('Restaurant ID missing after auth middleware');
      return res.status(401).json({ error: 'Not authenticated or invalid token payload' });
    }

    const dishId = req.params.id;
    const { name, description, price, category, ingredients } = req.body;
    const image = req.file;

    // Validate required fields
    if (!name || !description || !price || !category) {
      return res.status(400).json({ error: 'Required fields missing' });
    }

    // --- FIX: Use restaurantId from token for query --- 
    const dish = await Dish.findOne({ _id: dishId, restaurant_id: restaurantId });

    if (!dish) {
      return res.status(404).json({ error: 'Dish not found or unauthorized' });
    }

    dish.name = name;
    dish.description = description;
    dish.price = price;
    dish.category = category;
    dish.ingredients = ingredients;
    if (image) {
      dish.image = image.buffer;
    }

    await dish.save();

    res.json({
      message: 'Dish updated successfully',
      dish: {
        id: dishId,
        name,
        description,
        price,
        category,
        ingredients,
        image: image ? image.buffer.toString('base64') : null
      }
    });

  } catch (err) {
    console.error('Dish update error:', err);
    res.status(500).json({ error: 'Failed to update dish' });
  }
};

exports.getOrderById = async (req, res) => {
  try {
    const order = await OrderTable.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }
    res.json(order);
  } catch (error) {
    console.error('Error fetching order:', error);
    res.status(500).json({ message: 'Failed to fetch order', error: error.message });
  }
};

exports.getOrders = async (req, res) => {
  try {
    const restaurantId = req.restaurant.id;

    if (!restaurantId) {
      return res.status(401).json({ error: 'Restaurant not authenticated' });
    }

    const orders = await OrderTable.find({ restaurant_id: restaurantId })
      .populate('customer_id', 'name email') // Populate customer details
      .populate({ path: 'items.dishId', select: 'name' }); // Populate dish name within items

    res.json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
};

// Order Endpoints
exports.getOrdersByCustomerId = async (req, res) => {
  try {
    const customerId = req.params.customerId;
    // console.log(`[getOrdersByCustomerId] Received customerId param: ${customerId}, Type: ${typeof customerId}`); // Removed log
    const orders = await OrderTable.find({ customer_id: customerId })
      .populate('restaurant_id', 'name') // Populate restaurant name
      .populate({ path: 'items.dishId', select: 'name' }); // Populate dish name within items
    res.json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
};

exports.createOrder = async (req, res) => {
  console.log('createOrder called');
  // console.log('Request body:', req.body); // Can be noisy, uncomment if needed
  try {
    const { customerId, restaurantId, items, status, deliveryAddress, totalAmount } = req.body;

    if (!customerId || !restaurantId || !items || !totalAmount || !deliveryAddress) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const newOrder = new OrderTable({
      customer_id: customerId,
      restaurant_id: restaurantId,
      items: items,
      status: status || 'Pending', // Default status if not provided
      delivery_address: deliveryAddress,
      total_amount: totalAmount,
    });

    const savedOrder = await newOrder.save();
    console.log('Order created successfully:', savedOrder._id);

    // --- Kafka Integration Start ---
    const orderEvent = {
      orderId: savedOrder._id.toString(),
      customerId: savedOrder.customer_id,
      restaurantId: savedOrder.restaurant_id,
      items: savedOrder.items,
      totalAmount: savedOrder.total_amount,
      deliveryAddress: savedOrder.delivery_address,
      status: savedOrder.status,
      createdAt: savedOrder.createdAt,
    };

    // Use the imported shared producer instance
    await sendMessage(producer, KAFKA_TOPIC_ORDER_CREATED, [
      {
        key: savedOrder._id.toString(),
        value: JSON.stringify(orderEvent),
      },
    ]);
    console.log(`Published ${KAFKA_TOPIC_ORDER_CREATED} event for order ${savedOrder._id}`);
    // --- Kafka Integration End ---

    res.status(201).json({ id: savedOrder._id, message: 'Order created successfully' });
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ error: 'Failed to create order', details: error.message }); // Include error details
  }
};

exports.updateOrder = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body; // Only expecting status in the request body

    if (!id || !status) {
      return res.status(400).json({ error: 'Missing required fields: id and status are required.' });
    }

    // Find and update the order
    const updatedOrder = await OrderTable.findByIdAndUpdate(id, { status }, { new: true });

    if (!updatedOrder) {
      return res.status(404).json({ error: 'Order not found' });
    }

    // --- Kafka Integration Start ---
    // Prepare the status update event payload
    const statusUpdateEvent = {
      orderId: updatedOrder._id.toString(),
      status: updatedOrder.status,
      updatedAt: new Date().toISOString(),
      // Include other relevant details if needed, e.g., restaurantId
      restaurantId: updatedOrder.restaurant_id ? updatedOrder.restaurant_id.toString() : null,
    };

    // Publish the event to the status update topic using the shared producer
    await sendMessage(producer, KAFKA_TOPIC_ORDER_STATUS_UPDATE, [
      {
        key: updatedOrder._id.toString(), // Use order ID as the key
        value: JSON.stringify(statusUpdateEvent),
      },
    ]);
    console.log(`Published ${KAFKA_TOPIC_ORDER_STATUS_UPDATE} event for order ${updatedOrder._id}`);
    // --- Kafka Integration End ---

    // Respond to the HTTP request
    res.json({ message: 'Order status updated successfully', id: id }); // Keep original response
  } catch (error) {
    console.error('Error updating order status:', error);
    // Consider more specific error handling, e.g., Kafka publish errors
    res.status(500).json({ error: 'Failed to update order status' });
  }
};

exports.cancelOrder = async (req, res) => {
  try {
    const orderId = req.params.id; // Use the original string ID
    const customerId = req.session.customerId;

    // Validate if orderId is a valid MongoDB ObjectId
    if (!mongoose.Types.ObjectId.isValid(orderId)) {
      return res.status(400).json({ error: 'Invalid Order ID format' });
    }

    if (!customerId) {
      return res.status(401).json({ error: 'Unauthorized: You must be logged in.' });
    }

    // Find using the original string ObjectId
    const order = await OrderTable.findOne({ _id: orderId, customer_id: customerId });

    if (!order) {
      return res.status(404).json({ error: 'Order not found or unauthorized.' });
    }

    order.status = 'Cancelled';
    await order.save();

    // Return the original string ID
    res.json({ message: 'Order cancelled successfully', orderId: orderId });
  } catch (error) {
    console.error('Error cancelling order:', error);
    res.status(500).json({ error: 'Failed to cancel order' });
  }
};

// Favorite Endpoints
exports.getFavorites = async (req, res) => {
  try {
    const customerId = req.user.id; // Use req.user from checkCustomerAuth
    console.log(`[getFavorites] Attempting to fetch favorites for customer ID: ${customerId}`);

    if (!customerId) {
      console.warn('[getFavorites] Customer ID not found in req.user');
      return res.status(401).json({ error: 'Customer not authenticated' });
    }

    // Use the correct model name 'Favorite'
    const favorites = await Favorite.find({ customer_id: customerId })
      .populate('restaurant_id'); // Populate restaurant details

    // console.log(`[getFavorites] Raw favorites found in DB:`, JSON.stringify(favorites, null, 2));

    const favoriteRestaurants = favorites.map(fav => fav.restaurant_id).filter(Boolean);
    // console.log(`[getFavorites] Extracted restaurant objects after populate/filter:`, JSON.stringify(favoriteRestaurants, null, 2));

    const restaurantsWithImages = favoriteRestaurants.map(restaurant => ({
      ...restaurant.toObject(),
      image: restaurant.image ? restaurant.image.toString('base64') : null
    }));

    console.log(`[getFavorites] Sending ${restaurantsWithImages.length} restaurants to client.`);
    res.status(200).json(restaurantsWithImages);

  } catch (error) {
    console.error('[getFavorites] Error fetching favorites:', error);
    res.status(500).json({ error: 'Failed to fetch favorites' });
  }
};

exports.addFavorite = async (req, res) => {
  try {
    const customerId = req.user.id;
    // Use restaurantId (camelCase) from req.body.restaurant_id
    const restaurantId = req.body.restaurant_id;

    // Use restaurantId in checks
    if (!customerId) {
      return res.status(400).json({ message: 'Invalid customer or restaurant ID' });
    }
    if (!restaurantId || !mongoose.Types.ObjectId.isValid(restaurantId)) {
      return res.status(400).json({ message: 'Invalid restaurant ID format' });
    }

    const restaurantExists = await Restaurant.findById(restaurantId);
    if (!restaurantExists) {
      return res.status(404).json({ message: 'Restaurant not found' });
    }

    // --- FIX: Use correct variable name (restaurantId) in query --- 
    // ---      and correct field name (restaurant_id) in query object --- 
    const existingFavorite = await Favorite.findOne({
      customer_id: customerId,
      restaurant_id: restaurantId // Use the variable restaurantId (camelCase)
    });
    if (existingFavorite) {
      return res.status(409).json({ message: 'Restaurant already favorited' });
    }

    // --- FIX: Use correct variable name (restaurantId) for assignment --- 
    const newFavorite = new Favorite({
      customer_id: customerId,
      restaurant_id: restaurantId // Assign variable restaurantId (camelCase) to field restaurant_id
    });

    await newFavorite.save();
    res.status(201).json({ message: 'Restaurant added to favorites', favorite: newFavorite });

  } catch (error) {
    console.error('[addFavorite] Error adding favorite:', error);
    if (error.code === 11000) {
      return res.status(409).json({ message: 'Restaurant already favorited (concurrent request?)' });
    }
    res.status(500).json({ error: 'Failed to add favorite' });
  }
};

exports.removeFavorite = async (req, res) => { // Renamed back to removeFavorite
  try {
    const restaurantId = parseInt(req.params.restaurant_id, 10); // This line seems incorrect, should use req.params.restaurant_id directly

    // Use req.user.id from outer scope
    if (!req.user || !req.user.id || isNaN(restaurantId)) { // Check req.user.id existence and if restaurantId is a number (which it shouldn't be)
      return res.status(400).json({ message: 'Invalid customer or restaurant ID format' });
    }
    const customerId = req.user.id; // Declare customerId here using req.user
    const restaurantObjId = req.params.restaurant_id; // Keep the original string ID from params

    // Validate the restaurant ID from params
    if (!mongoose.Types.ObjectId.isValid(restaurantObjId)) {
      return res.status(400).json({ message: 'Invalid restaurant ID format in URL' });
    }

    // Use the correct model name 'Favorite'
    const result = await Favorite.deleteOne({ customer_id: customerId, restaurant_id: restaurantObjId });

    if (result.deletedCount === 0) {
      return res.status(404).json({ message: 'Favorite not found' });
    }

    res.status(200).json({ message: 'Restaurant removed from favorites' });

  } catch (error) {
    console.error('[removeFavorite] Error removing favorite:', error); // Add function name to log
    res.status(500).json({ error: 'Failed to remove favorite' });
  }
};
