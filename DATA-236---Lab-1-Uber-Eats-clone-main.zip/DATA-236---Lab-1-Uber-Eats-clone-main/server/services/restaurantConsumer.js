const {
    consumer: createConsumer, // Rename imported function
    sendMessage,
    createAndConnectProducer, // Import new function
    disconnectProducer,       // Import modified function
    KAFKA_TOPIC_ORDER_CREATED,
    KAFKA_TOPIC_ORDER_STATUS_UPDATE,
} = require('../kafka/client');
const OrderTable = require('../models/OrderTable'); // Corrected model name
const { connectDB } = require('../config/db'); // Import DB connection function
const mongoose = require('mongoose'); // Import mongoose for disconnection

const GROUP_ID = 'restaurant-service-group'; // Unique group ID for this consumer service

let localProducer = null; // Variable to hold the local producer
const restaurantConsumer = createConsumer({ groupId: GROUP_ID }); // Use renamed import

const run = async () => {
    // Connect to DB first
    await connectDB();
    console.log('Restaurant Consumer DB connected');

    // Create and connect the local producer for this service
    localProducer = await createAndConnectProducer();

    // Then connect Kafka consumer
    await restaurantConsumer.connect();
    await restaurantConsumer.subscribe({ topic: KAFKA_TOPIC_ORDER_CREATED, fromBeginning: true });
    console.log(`Restaurant consumer subscribed to ${KAFKA_TOPIC_ORDER_CREATED}`);

    await restaurantConsumer.run({
        eachMessage: async ({ topic, partition, message }) => {
            console.log(`Received message from ${topic} [${partition}]:`, {
                key: message.key.toString(),
                offset: message.offset,
                // value: message.value.toString(), // Can be large, log selectively
            });

            try {
                const orderEvent = JSON.parse(message.value.toString());
                const orderId = orderEvent.orderId;

                // 1. Simulate restaurant processing (e.g., check inventory, accept order)
                console.log(`Processing order ${orderId} for restaurant ${orderEvent.restaurantId}`);
                // Add a small delay to simulate work
                await new Promise(resolve => setTimeout(resolve, 500));

                // 2. Update order status in the database (example)
                const updatedStatus = 'Accepted'; // Or 'Preparing', etc.
                // Note: Direct DB update from another service might be debated in pure microservices.
                // Alternatives: API call to order service, or another Kafka event.
                // For simplicity here, we update directly if the model is accessible.
                let updatedOrder = null;
                if (OrderTable) {
                    updatedOrder = await OrderTable.findByIdAndUpdate(
                        orderId,
                        { status: updatedStatus },
                        { new: true }
                    );
                    if (!updatedOrder) {
                        console.warn(`Order ${orderId} not found for status update.`);
                        // Decide how to handle: skip, retry, dead-letter queue?
                        return; // Skip for now
                    }
                    console.log(`Order ${orderId} status updated to ${updatedStatus} in DB.`);
                }

                // 3. Publish order status update event
                const statusUpdateEvent = {
                    orderId: orderId,
                    status: updatedStatus,
                    updatedAt: new Date().toISOString(),
                    // Add other relevant details if needed
                };

                // Use the local producer instance
                await sendMessage(localProducer, KAFKA_TOPIC_ORDER_STATUS_UPDATE, [
                    {
                        key: orderId,
                        value: JSON.stringify(statusUpdateEvent),
                    },
                ]);
                console.log(`Published ${KAFKA_TOPIC_ORDER_STATUS_UPDATE} for order ${orderId}`);

                // Manually commit offset if not using autoCommit (default is true)
                // await restaurantConsumer.commitOffsets([{ topic, partition, offset: message.offset }])

            } catch (error) {
                console.error(`Error processing message for order ${message.key.toString()}:`, error);
                // Implement error handling: retry, dead-letter queue, logging
                // For now, we let it crash the consumer to restart (depending on process manager)
                // Or could choose to skip the message.
            }
        },
    });
};

const shutdown = async () => {
    console.log('Disconnecting restaurant consumer...');
    try {
        await restaurantConsumer.disconnect();
        console.log('Restaurant consumer disconnected.');
    } catch (err) {
        console.error('Error disconnecting Kafka consumer:', err);
    }

    // Disconnect the local producer for this service
    console.log('Disconnecting local Kafka producer...');
    await disconnectProducer(localProducer); // Pass the local instance

    console.log('Disconnecting MongoDB...');
    try {
        await mongoose.disconnect();
        console.log('MongoDB disconnected.');
    } catch (err) {
        console.error('Error disconnecting MongoDB:', err);
    }
};

// Graceful shutdown for THIS service (consumer + local producer + DB)
process.on('SIGINT', async () => {
    console.log('Restaurant consumer received SIGINT.');
    await shutdown();
    process.exit(0);
});
process.on('SIGTERM', async () => {
    console.log('Restaurant consumer received SIGTERM.');
    await shutdown();
    process.exit(0);
});

// Run the consumer
run().catch(error => {
    console.error('Error running restaurant consumer:', error);
    // Ensure disconnect on startup error
    shutdown().finally(() => process.exit(1));
});

module.exports = { run, shutdown }; // Export if needed elsewhere, though it runs itself 