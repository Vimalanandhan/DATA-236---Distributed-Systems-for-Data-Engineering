const jwt = require('jsonwebtoken');

const checkRestaurantAuth = (req, res, next) => {
  try {
    let token = null;
    const authHeader = req.headers.authorization;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.split(' ')[1];
    }

    if (!token) {
      console.log('No token found in Authorization header');
      return res.status(401).json({ error: 'Not authenticated: No token provided' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');

    if (!decoded.isRestaurant) {
      return res.status(401).json({ error: 'Not authorized as restaurant' });
    }

    req.restaurant = decoded;
    next();
  } catch (err) {
    console.error('Auth error:', err);
    return res.status(401).json({ error: 'Invalid token' });
  }
};

module.exports = { checkRestaurantAuth };