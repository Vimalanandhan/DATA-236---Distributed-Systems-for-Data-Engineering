const jwt = require('jsonwebtoken');

const checkCustomerAuth = (req, res, next) => {
    try {
        let token = null;
        const authHeader = req.headers.authorization;

        if (authHeader && authHeader.startsWith('Bearer ')) {
            token = authHeader.split(' ')[1];
        }

        if (!token) {
            console.log('No token found in Authorization header for customer');
            return res.status(401).json({ error: 'Not authenticated: No token provided' });
        }

        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');

        req.user = decoded;
        next();
    } catch (err) {
        console.error('Customer Auth Error:', err.message);
        if (err.name === 'TokenExpiredError') {
            return res.status(401).json({ error: 'Token expired' });
        }
        if (err.name === 'JsonWebTokenError') {
            return res.status(401).json({ error: 'Invalid token' });
        }
        return res.status(401).json({ error: 'Authentication failed' });
    }
};

module.exports = checkCustomerAuth;
