const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    profile_picture: {
        type: Buffer
    },
    country: {
        type: String
    },
    state: {
        type: String
    }
});

module.exports = mongoose.model('Customer', customerSchema);