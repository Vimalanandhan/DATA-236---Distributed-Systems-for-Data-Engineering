const mongoose = require('mongoose');

const orderTableSchema = new mongoose.Schema({
    customer_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Customer',
        required: true
    },
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Restaurant',
        required: true
    },
    items: [{
        dishId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Dish',
            required: true
        },
        quantity: {
            type: Number,
            required: true
        }
    }],
    status: {
        type: String,
        default: 'Pending'
    },
    delivery_address: {
        type: String,
        required: true
    },
    total_amount: {
        type: Number,
        required: true
    },
    order_date: {
        type: Date,
        default: Date.now
    }
});

const OrderTable = mongoose.model('OrderTable', orderTableSchema);

module.exports = OrderTable;