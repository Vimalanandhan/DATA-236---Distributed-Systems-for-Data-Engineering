const mongoose = require('mongoose');

const restaurantSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    location: {
        type: String,
        required: true
    },
    cuisine: {
        type: String,
        required: true,
        enum: ['Italian', 'Chinese', 'Japanese', 'Indian', 'Mexican', 'American', 'Thai', 'Mediterranean', 'Other']
    },
    description: {
        type: String
    },
    contact_info: {
        type: String
    },
    image: {
        type: Buffer
    },
    timings: {
        type: String
    }
});

module.exports = mongoose.model('Restaurant', restaurantSchema);