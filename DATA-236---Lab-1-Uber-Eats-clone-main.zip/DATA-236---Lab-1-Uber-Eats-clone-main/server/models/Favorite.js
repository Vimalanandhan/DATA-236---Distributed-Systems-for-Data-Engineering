const mongoose = require('mongoose');

const favoriteSchema = new mongoose.Schema({
    customer_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Customer', // Reference to the Customer model
        required: true
    },
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Restaurant', // Reference to the Restaurant model
        required: true
    }
}, {
    timestamps: true // Automatically add createdAt and updatedAt fields
});

// Ensure a customer cannot favorite the same restaurant multiple times
favoriteSchema.index({ customer_id: 1, restaurant_id: 1 }, { unique: true });

const Favorite = mongoose.model('Favorite', favoriteSchema);

module.exports = Favorite; 