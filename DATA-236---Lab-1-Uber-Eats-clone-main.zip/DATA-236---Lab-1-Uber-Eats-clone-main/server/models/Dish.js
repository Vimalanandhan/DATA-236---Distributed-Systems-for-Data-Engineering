const mongoose = require('mongoose');

const dishSchema = new mongoose.Schema({
    restaurant_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Restaurant',
        required: true
    },
    name: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        required: true
    },
    category: {
        type: String
    },
    ingredients: {
        type: String
    },
    image: {
        type: Buffer
    }
});

module.exports = mongoose.model('Dish', dishSchema);