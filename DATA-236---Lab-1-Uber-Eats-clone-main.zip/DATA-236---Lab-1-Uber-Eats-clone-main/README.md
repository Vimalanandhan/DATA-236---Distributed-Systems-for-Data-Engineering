# Uber Eats Clone

This project is a clone of the popular food delivery service, Uber Eats, built using the MERN stack (MongoDB, Express, React, Node.js). 

## Features

- User authentication and management
- Restaurant listing and details
- Menu display for each restaurant
- Order management for users

## Getting Started

### Prerequisites

- Node.js
- MongoDB

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/uber-eats-clone.git
   ```

2. Navigate to the client directory and install dependencies:
   ```
   cd uber-eats-clone/client
   npm install
   ```

3. Navigate to the server directory and install dependencies:
   ```
   cd ../server
   npm install
   ```

### Running the Application

1. Start the server:
   ```
   cd server
   node src/server.js
   ```

2. In a new terminal, start the client:
   ```
   cd client
   npm start
   ```

The application should now be running on `http://localhost:3000`. 

## Contributing

Feel free to submit issues or pull requests for any improvements or features you'd like to see!