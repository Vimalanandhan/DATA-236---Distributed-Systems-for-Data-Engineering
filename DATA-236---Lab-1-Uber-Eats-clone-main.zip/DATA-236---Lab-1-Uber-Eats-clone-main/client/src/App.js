import React, { useState, useEffect, useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux'; // Import useSelector
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom'; // Import useNavigate and useLocation
import { loginSuccess, logout } from './store/slices/authSlice'; // Import logout action
import HomePage from './components/HomePage/HomePage';
import LandingPage from './components/LandingPage/LandingPage';
import Signup from './components/Signup/Signup';
import Login from './components/Login/Login';
import RestaurantProfile from './components/RestaurantProfile/RestaurantProfile';
import RestaurantLogin from './components/RestaurantAuth/RestaurantLogin';
import RestaurantProtectedRoute from './components/RestaurantAuth/RestaurantProtectedRoute';
import RestaurantSignup from './components/RestaurantAuth/RestaurantSignup';
import RestaurantDetails from './components/RestaurantDetails/RestaurantDetails';
import Cart from './components/Cart/Cart';
import CustomerProfile from './components/CustomerProfile/CustomerProfile';
import CustomerOrders from './components/CustomerOrders/CustomerOrders';
import FavoritesPage from './components/FavoritesPage/FavoritesPage';
import OrderDetails from './components/OrderDetails/OrderDetails';
import CustomerProtectedRoute from './components/CustomerAuth/CustomerProtectedRoute';
import PublicRouteWrapper from './components/AuthUtils/PublicRouteWrapper'; // <-- Import the wrapper

import './App.css';

// Helper component to manage navigation within App
function NavigationManager() {
  const navigate = useNavigate();
  window.appNavigate = navigate; // Assign navigate to a global variable (use cautiously)
  return null;
}

// Define LayoutWrapper component here - Remove sidebar props and Navbar
const LayoutWrapper = ({
  // isExpanded,
  // setIsExpanded,
  isCustomerAuth, // Keep auth state if needed elsewhere, or remove if only used by Navbar
  isRestaurantAuth,
  handleSignOut, // Keep signout if needed elsewhere
  children // To render the main content
}) => {
  const location = useLocation();
  // Remove logic related to showing Navbar
  // const shouldShowNavbar = location.pathname !== '/';

  return (
    // Remove classes related to sidebar state
    // <div className={`app-container ${isExpanded ? 'sidebar-expanded' : 'sidebar-collapsed'}`}>
    <div className="app-container">
      {/* Remove Navbar rendering */}
      {/* {shouldShowNavbar && (
        <Navbar
          isExpanded={isExpanded}
          setIsExpanded={setIsExpanded}
          isCustomerAuth={isCustomerAuth}
          isRestaurantAuth={isRestaurantAuth}
          handleSignOut={handleSignOut}
        />
      )} */}
      {/* Render the main content passed as children */}
      {children}
    </div>
  );
};

function App() {
  // --- Add Loading State --- 
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  // -------------------------

  // Auth State - Lifted from Navbar
  const [isRestaurantAuth, setIsRestaurantAuth] = useState(false);
  const [isCustomerAuth, setIsCustomerAuth] = useState(false);

  const dispatch = useDispatch();
  // const navigate = useNavigate(); // Cannot use useNavigate here directly

  // --- Get current Redux auth state --- 
  const isReduxAuthenticated = useSelector(state => state.auth.isAuthenticated);
  // ------------------------------------

  // Check auth status
  const checkAuthStatus = async () => {
    console.log('[App.js] Starting auth status check...');
    let customerOk = false;
    let restaurantOk = false;

    try {
      // Check customer auth
      const customerToken = localStorage.getItem('customerAuthToken');
      if (customerToken) {
        console.log('[App.js] Checking customer auth via /me endpoint...');
        try {
          const apiUrl = process.env.REACT_APP_API_URL || '/api';
          const res = await fetch(`${apiUrl}/api/auth/me`, {
            headers: { 'Authorization': `Bearer ${customerToken}` }
          });
          customerOk = res.ok;
          if (!customerOk) {
            localStorage.removeItem('customerAuthToken');
            console.log('[App.js] Removed invalid customer token from localStorage.');
          }
        } catch (error) {
          console.error('Customer auth check via /me failed:', error);
          localStorage.removeItem('customerAuthToken');
          customerOk = false;
        }
      }

      // Check restaurant auth
      const restaurantToken = localStorage.getItem('restaurantAuthToken');
      if (restaurantToken) {
        console.log('[App.js] Checking restaurant auth via localStorage token...');
        try {
          const apiUrl = process.env.REACT_APP_API_URL || '/api';
          const res = await fetch(`${apiUrl}/api/auth/restaurant/me`, {
            headers: { 'Authorization': `Bearer ${restaurantToken}` }
          });
          restaurantOk = res.ok;
          if (!restaurantOk) {
            localStorage.removeItem('restaurantAuthToken');
            console.log('[App.js] Removed invalid restaurant token from localStorage.');
          }
        } catch (error) {
          console.error('Restaurant auth check failed:', error);
          localStorage.removeItem('restaurantAuthToken');
          restaurantOk = false;
        }
      }

      // Update local state for potential UI elements (like Navbar, if needed)
      setIsCustomerAuth(customerOk);
      setIsRestaurantAuth(restaurantOk);

      // Dispatch logout only if Redux thinks user is logged in but checks failed
      if (!customerOk && !restaurantOk && isReduxAuthenticated) {
        console.log('[App.js] No valid auth found but Redux state was true, dispatching logout.');
        dispatch(logout());
      }

    } catch (err) {
      console.error('[App.js] Error during checkAuthStatus main block:', err);
    } finally {
      console.log('[App.js] Auth status check complete.');
      setIsAuthLoading(false);
    }
  };

  // Check auth on initial load
  useEffect(() => {
    checkAuthStatus();
  }, []); // Only on mount

  // Re-check auth status if the Redux state indicates a logout unexpectedly?
  // This is complex, might be better handled by logout logic itself
  // useEffect(() => {
  //    if (!isReduxAuthenticated && (localStorage.getItem('customerAuthToken') || localStorage.getItem('restaurantAuthToken'))) {
  //       console.warn('Redux logged out but token exists? Re-checking...');
  //       checkAuthStatus();
  //    }
  // }, [isReduxAuthenticated]);

  // Handle Sign Out (lifted from Navbar)
  const handleSignOut = async () => {
    // const customerToken = localStorage.getItem('customerAuthToken'); // <-- REMOVE
    const restaurantToken = localStorage.getItem('restaurantAuthToken');
    let endpoint = '';
    let baseUrl = process.env.REACT_APP_API_URL || ''; // Define baseUrl
    let needsAuthHeader = false; // Flag to track if Authorization header is needed
    let tokenForHeader = null;

    if (isRestaurantAuth && restaurantToken) {
      endpoint = `${baseUrl}/api/auth/restaurant/logout`;
      needsAuthHeader = true;
      tokenForHeader = restaurantToken;
      console.log('[App.js] Signing out restaurant...');
    } else if (isCustomerAuth) { // Check Redux state or local state instead of token
      endpoint = `${baseUrl}/api/auth/customer/logout`;
      needsAuthHeader = false; // Customer logout relies on cookie
      console.log('[App.js] Signing out customer...');
    }

    // Attempt server logout if possible
    if (endpoint) {
      try {
        const fetchOptions = {
          method: 'POST',
          headers: {},
          credentials: 'include' // Send cookies for both requests
        };
        if (needsAuthHeader && tokenForHeader) {
          fetchOptions.headers['Authorization'] = `Bearer ${tokenForHeader}`;
          delete fetchOptions.credentials; // Don't send both Authorization header and credentials:include usually
        }

        console.log(`[App.js] Calling logout endpoint: ${endpoint} with options:`, fetchOptions);
        const response = await fetch(endpoint, fetchOptions);
        if (!response.ok) {
          console.error(`[App.js] Server logout failed for ${endpoint}:`, response.status, await response.text());
        }
      } catch (error) {
        console.error('[App.js] Logout network error:', error);
      }
    }

    // Always clear relevant local storage, state, and Redux state
    // localStorage.removeItem('customerAuthToken'); // <-- REMOVE (was never there)
    localStorage.removeItem('restaurantAuthToken'); // Keep clearing restaurant token
    setIsCustomerAuth(false);
    setIsRestaurantAuth(false);
    dispatch(logout()); // Dispatch Redux logout action

    if (window.appNavigate) {
      window.appNavigate('/');
    } else {
      console.error('Navigation function not available');
    }
  };


  // Previous Redux-based checkSession - Can be removed or adapted
  // useEffect(() => {
  //   const checkSession = async () => { ... };
  //   checkSession();
  // }, [dispatch]);

  // --- Conditional Rendering based on Loading State --- 
  if (isAuthLoading) {
    // You can replace this with a nicer loading spinner component
    return <div>Loading application...</div>;
  }
  // --------------------------------------------------

  return (
    <Router>
      {/* Helper component to capture navigate function */}
      <NavigationManager />
      {/* Use LayoutWrapper to wrap Navbar and main content */}
      {/* Remove sidebar state props from LayoutWrapper */}
      <LayoutWrapper
        // isExpanded={isExpanded}
        // setIsExpanded={setIsExpanded}
        isCustomerAuth={isCustomerAuth}
        isRestaurantAuth={isRestaurantAuth}
        handleSignOut={handleSignOut}
      >
        <main className="main-content">
          <Routes>
            {/* Public Routes - Redirect if logged in */}
            <Route
              path="/"
              element={
                <PublicRouteWrapper>
                  <LandingPage />
                </PublicRouteWrapper>
              }
            />
            <Route
              path="/signup"
              element={
                <PublicRouteWrapper>
                  <Signup />
                </PublicRouteWrapper>
              }
            />
            <Route
              path="/login"
              element={
                <PublicRouteWrapper>
                  <Login />
                </PublicRouteWrapper>
              }
            />

            {/* Restaurant Public Routes (Consider wrapping if needed) */}
            <Route path="/restaurant/login" element={<RestaurantLogin />} />
            <Route path="/restaurant/signup" element={<RestaurantSignup />} />
            <Route path="/restaurant/:id" element={<RestaurantDetails />} key={window.location.pathname} />

            {/* Customer Protected Routes */}
            <Route
              path="/home"
              element={
                <CustomerProtectedRoute>
                  <HomePage />
                </CustomerProtectedRoute>
              }
            />
            <Route
              path="/profile"
              element={
                <CustomerProtectedRoute>
                  <CustomerProfile />
                </CustomerProtectedRoute>
              }
            />
            <Route
              path="/customer/orders"
              element={
                <CustomerProtectedRoute>
                  <CustomerOrders />
                </CustomerProtectedRoute>
              }
            />
            <Route
              path="/customer/orders/:orderId"
              element={
                <CustomerProtectedRoute>
                  <OrderDetails />
                </CustomerProtectedRoute>
              }
            />
            <Route
              path="/cart"
              element={
                <CustomerProtectedRoute>
                  <Cart />
                </CustomerProtectedRoute>
              }
            />
            <Route
              path="/favorites"
              element={
                <CustomerProtectedRoute>
                  <FavoritesPage />
                </CustomerProtectedRoute>
              }
            />

            {/* Restaurant Protected Routes */}
            <Route
              path="/restaurant/profile"
              element={
                <RestaurantProtectedRoute>
                  <RestaurantProfile />
                </RestaurantProtectedRoute>
              }
            />
            <Route
              path="/restaurant/dashboard"
              element={
                <RestaurantProtectedRoute>
                  <RestaurantProfile /> { /* Should this be a different dashboard component? */}
                </RestaurantProtectedRoute>
              }
            />

            {/* Catch All */}
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>
      </LayoutWrapper>
    </Router>
  );
}

export default App;
