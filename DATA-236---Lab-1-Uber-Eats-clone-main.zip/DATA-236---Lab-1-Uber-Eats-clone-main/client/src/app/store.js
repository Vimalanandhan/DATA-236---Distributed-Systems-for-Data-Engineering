import { configureStore } from '@reduxjs/toolkit';
import customerReducer from '../features/customer/customerSlice';
import cartReducer from '../features/cart/cartSlice';
import restaurantReducer from '../features/restaurant/restaurantSlice';

export const store = configureStore({
    reducer: {
        customer: customerReducer,
        cart: cartReducer,
        restaurant: restaurantReducer,
    },
});
