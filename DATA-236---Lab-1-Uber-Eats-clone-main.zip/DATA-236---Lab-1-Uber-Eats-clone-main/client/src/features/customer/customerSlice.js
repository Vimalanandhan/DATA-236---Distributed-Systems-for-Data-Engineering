import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

// Async thunk to fetch customer data
export const fetchCustomer = createAsyncThunk(
    'customer/fetchCustomer',
    async (customerId, { rejectWithValue }) => {
        try {
            const response = await fetch(`/api/customers/${customerId}`, { credentials: 'include' });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ error: 'Failed to parse error response' }));
                return rejectWithValue(errorData.error || response.statusText);
            }

            const customerData = await response.json();

            // Server now sends profile_picture as Base64 string or null, no client conversion needed.

            return customerData;
        } catch (error) {
            return rejectWithValue(error.message);
        }
    }
);

// Async thunk to update customer profile
export const updateCustomerProfile = createAsyncThunk(
    'customer/updateCustomerProfile',
    async ({ customerId, formData }, { rejectWithValue }) => {
        try {
            const response = await fetch(`/api/customers/profile`, {
                method: 'PUT',
                body: formData,
                credentials: 'include',
            });

            if (!response.ok) {
                const errorData = await response.json();
                return rejectWithValue(errorData.error || response.statusText);
            }

            const updatedCustomer = await response.json();

            // Server now sends profile_picture as Base64 string or null, no client conversion needed.

            return updatedCustomer;
        } catch (error) {
            return rejectWithValue(error.message);
        }
    }
);


export const logout = createAsyncThunk(
    'customer/logout',
    async (_, { rejectWithValue, dispatch }) => {
        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL || ''}/api/auth/customer/logout`, {
                method: 'POST',
                credentials: 'include',
            });

            if (!response.ok) {
                const errorData = await response.json();
                return rejectWithValue(errorData.error || 'Logout failed');
            }
            dispatch(clearCustomerData());
            return 'Logout successful';
        } catch (error) {
            return rejectWithValue(error.message);
        }
    }
);

const customerSlice = createSlice({
    name: 'customer',
    initialState: {
        id: null,
        name: null,
        email: null,
        country: null,
        state: null,
        profile_picture: null,
        status: 'idle',
        error: null,
        isAuthenticated: false,
    },
    reducers: {
        setCustomer: (state, action) => {
            // console.log('[customerSlice] setCustomer reducer called. Payload:', action.payload); // Removed log
            state.id = action.payload.id;
            state.name = action.payload.name;
            state.email = action.payload.email;
            state.isAuthenticated = true;
        },
        clearCustomerData: (state) => {
            state.id = null;
            state.name = null;
            state.email = null;
            state.country = null;
            state.state = null;
            state.profile_picture = null;
            state.status = 'idle';
            state.error = null;
            state.isAuthenticated = false;
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchCustomer.pending, (state) => {
                state.status = 'loading';
                state.error = null;
            })
            .addCase(fetchCustomer.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.id = action.payload.id;
                state.name = action.payload.name;
                state.email = action.payload.email;
                state.country = action.payload.country;
                state.state = action.payload.state;
                state.profile_picture = action.payload.profile_picture;
            })
            .addCase(fetchCustomer.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload;
            })
            .addCase(updateCustomerProfile.pending, (state) => {
                state.status = 'loading';
                state.error = null;
            })
            .addCase(updateCustomerProfile.fulfilled, (state, action) => {
                // Payload from server is { message: '...', customer: {...} }
                // Access the nested customer object
                if (action.payload && action.payload.customer) {
                    const updatedCustomer = action.payload.customer;
                    state.status = 'succeeded';
                    state.name = updatedCustomer.name;
                    state.email = updatedCustomer.email;
                    state.country = updatedCustomer.country;
                    state.state = updatedCustomer.state;
                    // Ensure profile picture is updated correctly (should be Base64 string or null from server)
                    state.profile_picture = updatedCustomer.profile_picture;
                } else {
                    // Handle unexpected payload format
                    console.error("Update profile fulfilled, but payload format is unexpected:", action.payload);
                    state.status = 'failed'; // Or handle appropriately
                    state.error = 'Received unexpected data after profile update.';
                }
            })
            .addCase(updateCustomerProfile.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload;
            })
            .addCase(logout.fulfilled, (state) => {
                state.status = 'idle';
                state.id = null;
                state.name = null;
                state.email = null;
                state.country = null;
                state.state = null;
                state.profile_picture = null;
                state.isAuthenticated = false;
                state.error = null;
            })
            .addCase(logout.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.payload;
            });
    },
});

export const { setCustomer, clearCustomerData } = customerSlice.actions;
export default customerSlice.reducer;
