import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

const initialState = {
    restaurants: [],
    menus: {},
    status: 'idle',
    error: null,
};

export const fetchRestaurants = createAsyncThunk(
    'restaurant/fetchRestaurants',
    async () => {
        const response = await fetch('/api/restaurants'); // Assuming this endpoint exists
        const data = await response.json();
        return data;
    }
);

export const fetchMenu = createAsyncThunk(
    'restaurant/fetchMenu',
    async (restaurantId) => {
        const response = await fetch(`/api/restaurants/${restaurantId}/menu`); // Assuming this endpoint exists
        const data = await response.json();
        return { restaurantId, menu: data };
    }
);

const restaurantSlice = createSlice({
    name: 'restaurant',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchRestaurants.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchRestaurants.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.restaurants = action.payload;
            })
            .addCase(fetchRestaurants.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            })
            .addCase(fetchMenu.pending, (state) => {
                state.status = 'loading';
            })
            .addCase(fetchMenu.fulfilled, (state, action) => {
                state.status = 'succeeded';
                state.menus[action.payload.restaurantId] = action.payload.menu;
            })
            .addCase(fetchMenu.rejected, (state, action) => {
                state.status = 'failed';
                state.error = action.error.message;
            });
    },
});

export const selectRestaurants = (state) => state.restaurant.restaurants;
export const selectRestaurantStatus = (state) => state.restaurant.status;
export const selectRestaurantError = (state) => state.restaurant.error;

export default restaurantSlice.reducer;