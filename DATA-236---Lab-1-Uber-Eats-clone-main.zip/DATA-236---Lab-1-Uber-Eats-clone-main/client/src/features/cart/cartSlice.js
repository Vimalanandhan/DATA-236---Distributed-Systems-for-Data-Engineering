import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

const initialState = {
    items: [],
    orderStatus: 'idle', // 'idle' | 'loading' | 'succeeded' | 'failed'
    error: null,
};

export const submitOrder = createAsyncThunk(
    'cart/submitOrder',
    async (orderData) => {
        // Replace with your actual API endpoint
        const response = await fetch('/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(orderData),
        });

        if (!response.ok) {
            throw new Error('Failed to submit order');
        }

        const data = await response.json();
        return data;
    }
);

export const cartSlice = createSlice({
    name: 'cart',
    initialState,
    reducers: {
        addToCart: (state, action) => {
            const existingItem = state.items.find((item) => item.id === action.payload.id);
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                state.items.push({ ...action.payload, quantity: 1, restaurant_id: action.payload.restaurant_id });
            }
        },
        removeFromCart: (state, action) => {
            state.items = state.items.filter((item) => item.id !== action.payload);
        },
        decreaseQuantity: (state, action) => {
            const itemIndex = state.items.findIndex((item) => item.id === action.payload);
            if (itemIndex !== -1 && state.items[itemIndex].quantity > 1) {
                state.items[itemIndex].quantity -= 1;
            } else if (itemIndex !== -1 && state.items[itemIndex].quantity === 1) {
                state.items.splice(itemIndex, 1);
            }
        },
        increaseQuantity: (state, action) => {
            const itemIndex = state.items.findIndex((item) => item.id === action.payload);
            if (itemIndex !== -1) {
                state.items[itemIndex].quantity += 1;
            }
        },
        clearCart: (state) => {
            state.items = [];
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(submitOrder.pending, (state) => {
                state.orderStatus = 'loading';
            })
            .addCase(submitOrder.fulfilled, (state) => {
                state.orderStatus = 'succeeded';
                state.items = []; // Clear the cart after successful order
            })
            .addCase(submitOrder.rejected, (state, action) => {
                state.orderStatus = 'failed';
                state.error = action.error.message;
            });
    },
});

export const { addToCart, removeFromCart, decreaseQuantity, increaseQuantity, clearCart } = cartSlice.actions;

export const selectCartItems = (state) => state.cart.items;
export const selectOrderStatus = (state) => state.cart.orderStatus;
export const selectCartError = (state) => state.cart.error;

export default cartSlice.reducer;
