import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

const initialState = {
    restaurants: [],
    selectedRestaurant: null,
    loading: false,
    error: null,
};

// Async thunk for fetching restaurants
export const fetchRestaurants = createAsyncThunk(
    'restaurants/fetchRestaurants',
    async (_, { rejectWithValue }) => {
        try {
            // Use relative path for Nginx proxy
            const response = await fetch('/api/restaurants', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
                // credentials: 'include' // Keep or remove based on actual need
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ message: `HTTP error! status: ${response.status}` }));
                console.error('Error fetching restaurants:', errorData);
                return rejectWithValue(errorData.message || `Failed to fetch restaurants. Status: ${response.status}`);
            }

            const data = await response.json();
            console.log('Fetched restaurants:', data);
            return data;
        } catch (error) {
            console.error('Network or parsing error fetching restaurants:', error);
            return rejectWithValue(error.message || 'An unexpected error occurred');
        }
    }
);

// Async thunk for fetching a single restaurant
export const fetchRestaurantById = createAsyncThunk(
    'restaurants/fetchRestaurantById',
    async (id, { rejectWithValue }) => {
        try {
            // Use relative path for Nginx proxy
            const response = await fetch(`/api/restaurants/${id}`);
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Failed to fetch restaurant');
            }
            return response.json();
        } catch (error) {
            console.error('Error fetching restaurant by ID:', error);
            return rejectWithValue(error.message);
        }
    }
);

const restaurantSlice = createSlice({
    name: 'restaurants',
    initialState,
    reducers: {
        setSelectedRestaurant: (state, action) => {
            state.selectedRestaurant = action.payload;
        },
        clearSelectedRestaurant: (state) => {
            state.selectedRestaurant = null;
        },
    },
    extraReducers: (builder) => {
        builder
            // Handle fetchRestaurants
            .addCase(fetchRestaurants.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchRestaurants.fulfilled, (state, action) => {
                state.loading = false;
                state.restaurants = action.payload;
            })
            .addCase(fetchRestaurants.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message;
            })
            // Handle fetchRestaurantById
            .addCase(fetchRestaurantById.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(fetchRestaurantById.fulfilled, (state, action) => {
                state.loading = false;
                state.selectedRestaurant = action.payload;
            })
            .addCase(fetchRestaurantById.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error.message;
            });
    },
});

export const { setSelectedRestaurant, clearSelectedRestaurant } = restaurantSlice.actions;

// Selectors
export const selectRestaurants = (state) => state.restaurants.restaurants;
export const selectSelectedRestaurant = (state) => state.restaurants.selectedRestaurant;
export const selectRestaurantLoading = (state) => state.restaurants.loading;
export const selectRestaurantError = (state) => state.restaurants.error;

export default restaurantSlice.reducer; 