import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    currentOrder: null,
    orderHistory: [],
    orderStatus: null, // 'pending', 'confirmed', 'preparing', 'ready', 'delivered', 'cancelled'
    loading: false,
    error: null,
};

const orderSlice = createSlice({
    name: 'order',
    initialState,
    reducers: {
        createOrderStart: (state) => {
            state.loading = true;
            state.error = null;
        },
        createOrderSuccess: (state, action) => {
            state.loading = false;
            state.currentOrder = action.payload;
            state.orderStatus = 'pending';
        },
        createOrderFailure: (state, action) => {
            state.loading = false;
            state.error = action.payload;
        },
        updateOrderStatus: (state, action) => {
            state.orderStatus = action.payload;
        },
        completeOrder: (state) => {
            if (state.currentOrder) {
                state.orderHistory.push({
                    ...state.currentOrder,
                    status: 'delivered',
                    completedAt: new Date().toISOString(),
                });
                state.currentOrder = null;
                state.orderStatus = null;
            }
        },
        cancelOrder: (state) => {
            if (state.currentOrder) {
                state.orderHistory.push({
                    ...state.currentOrder,
                    status: 'cancelled',
                    cancelledAt: new Date().toISOString(),
                });
                state.currentOrder = null;
                state.orderStatus = null;
            }
        },
        setLoading: (state, action) => {
            state.loading = action.payload;
        },
        setError: (state, action) => {
            state.error = action.payload;
        },
    },
});

export const {
    createOrderStart,
    createOrderSuccess,
    createOrderFailure,
    updateOrderStatus,
    completeOrder,
    cancelOrder,
    setLoading,
    setError,
} = orderSlice.actions;

export default orderSlice.reducer; 