import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './RestaurantAuth.css';
import { Button } from 'react-bootstrap';

const RestaurantSignup = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    location: '',
    description: '',
    contact_info: '',
    timings: '',
    cuisine: ''
  });
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Use relative path for API URL fallback
      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const signupUrl = `${apiUrl}/auth/restaurant/signup`;

      console.log('Submitting signup form to:', signupUrl);
      console.log('Form data being sent:', formData); // Debug log

      const response = await fetch(signupUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        navigate('/restaurant/dashboard');
      } else {
        const data = await response.json();
        setError(data.error || 'Signup failed');
      }
    } catch (err) {
      console.error('Signup failed:', err);
      if (err instanceof SyntaxError) {
        setError('Failed to process server response. Is the server running and configured correctly?');
      } else {
        setError('Network error occurred while trying to sign up.');
      }
    }
  };

  return (
    <div className="restaurant-auth-container">
      <h2>Register Your Restaurant</h2>
      {error && <div className="error-message">{error}</div>}
      <form onSubmit={handleSubmit} className="auth-form">
        <div className="form-group">
          <label>Restaurant Name</label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label>Cuisine</label>
          <input
            type="text"
            value={formData.cuisine}
            onChange={(e) => setFormData({ ...formData, cuisine: e.target.value })}
            placeholder="e.g., Italian, Mexican, Indian"
            required
          />
        </div>
        <div className="form-group">
          <label>Location</label>
          <input
            type="text"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label>Description</label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label>Contact Info</label>
          <input
            type="text"
            value={formData.contact_info}
            onChange={(e) => setFormData({ ...formData, contact_info: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label>Timings</label>
          <input
            type="text"
            value={formData.timings}
            onChange={(e) => setFormData({ ...formData, timings: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label>Cuisine</label>
          <input
            type="text"
            value={formData.cuisine}
            onChange={(e) => setFormData({ ...formData, cuisine: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <Button variant="primary" type="submit" className="w-100">
            Sign Up
          </Button>
        </div>
        <div className="text-center mt-3">
          <p>Already have a restaurant account? <Link to="/restaurant/login">Restaurant Login</Link></p>
          <p className="mt-2">Are you a customer? <Link to="/login">Customer Login</Link> | <Link to="/signup">Customer Signup</Link></p>
          <p className="mt-2"><Link to="/">Back to Home</Link></p>
        </div>
      </form>
    </div>
  );
};

export default RestaurantSignup;