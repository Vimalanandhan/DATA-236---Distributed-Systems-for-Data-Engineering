import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './RestaurantAuth.css';
import { Button } from 'react-bootstrap';

const RestaurantLogin = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const loginUrl = `${apiUrl}/auth/restaurant/login`;

      console.log('Making restaurant login request to:', loginUrl);
      console.log('Form data being sent:', formData);

      const response = await fetch(loginUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (response.ok) {
        console.log('Login successful');
        if (data.token) {
          localStorage.setItem('restaurantAuthToken', data.token);
          navigate('/restaurant/profile');
        } else {
          console.error('Login successful, but no token received from server.');
          setError('Login failed: No token received.');
        }
      } else {
        console.error('Login failed:', data.error);
        setError(data.error || 'Login failed');
      }
    } catch (err) {
      console.error('Network error:', err);
      if (err instanceof SyntaxError) {
        setError('Failed to process server response. Is the server running and configured correctly?');
      } else {
        setError('Network error occurred while trying to log in.');
      }
    }
  };

  return (
    <div className="restaurant-auth-container">
      <h2>Restaurant Login</h2>
      {error && <div className="error-message">{error}</div>}
      <form onSubmit={handleSubmit} className="auth-form">
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <Button variant="primary" type="submit" className="w-100">
            Login
          </Button>
        </div>
        <div className="text-center mt-3">
          <p>Don't have a restaurant account? <Link to="/restaurant/signup">Add Restaurant</Link></p>
          <p className="mt-2">Are you a customer? <Link to="/login">Customer Login</Link> | <Link to="/signup">Customer Signup</Link></p>
          <p className="mt-2"><Link to="/">Back to Home</Link></p>
        </div>
      </form>
    </div>
  );
};

export default RestaurantLogin;