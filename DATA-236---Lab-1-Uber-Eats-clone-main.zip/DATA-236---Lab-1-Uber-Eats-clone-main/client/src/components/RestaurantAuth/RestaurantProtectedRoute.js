import { Navigate, useLocation } from 'react-router-dom';

const RestaurantProtectedRoute = ({ children }) => {
  // Check localStorage for the token instead of document.cookie
  const restaurantToken = localStorage.getItem('restaurantAuthToken');
  const isAuthenticated = !!restaurantToken; // Convert token presence to boolean
  const location = useLocation();

  console.log('[RestaurantProtectedRoute] Checking auth. Token found:', isAuthenticated);

  if (!isAuthenticated) {
    console.log('[RestaurantProtectedRoute] Not authenticated, redirecting to /restaurant/login');
    // Redirect to restaurant login, saving the intended location
    return <Navigate to="/restaurant/login" state={{ from: location }} replace />;
  }

  return children;
};

export default RestaurantProtectedRoute;