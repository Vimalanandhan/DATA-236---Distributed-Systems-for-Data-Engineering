import React from 'react';
import './DeliveryToggle.css';

const DeliveryToggle = ({ isDelivery, onToggle }) => {
  return (
    <div className="delivery-toggle">
      <button 
        className={`toggle-btn ${isDelivery ? 'active' : ''}`}
        onClick={() => onToggle(true)}
      >
        Delivery
      </button>
      <button 
        className={`toggle-btn ${!isDelivery ? 'active' : ''}`}
        onClick={() => onToggle(false)}
      >
        Pickup
      </button>
    </div>
  );
};

export default DeliveryToggle;