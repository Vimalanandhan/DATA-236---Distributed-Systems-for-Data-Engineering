import React from 'react';
import { FaBars } from 'react-icons/fa';

const Hamburger = ({ onToggle }) => {
  return (
    <button className="hamburger-button" onClick={onToggle}>
      <FaBars />
    </button>
  );
};

export default Hamburger;
