import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import './CustomerDashboard.css';

const CustomerDashboard = () => {
  const location = useLocation();

  return (
    <div className="dashboard-container">
      <div className="dashboard-content">
        <Outlet />
      </div>
    </div>
  );
};

export default CustomerDashboard;