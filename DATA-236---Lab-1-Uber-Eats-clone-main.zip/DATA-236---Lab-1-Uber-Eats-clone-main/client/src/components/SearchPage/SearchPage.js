import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaArrowLeft } from 'react-icons/fa';
import { useDispatch, useSelector } from 'react-redux';
import { fetchRestaurants, selectRestaurants, selectRestaurantLoading, selectRestaurantError } from '../../store/slices/restaurantSlice';
import './SearchPage.css';

const SearchPage = () => {
    const navigate = useNavigate();
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredRestaurants, setFilteredRestaurants] = useState([]);
    const dispatch = useDispatch();
    const restaurants = useSelector(selectRestaurants);
    const loading = useSelector(selectRestaurantLoading);
    const error = useSelector(selectRestaurantError);

    // Fetch all restaurants on component mount
    useEffect(() => {
        dispatch(fetchRestaurants());
    }, [dispatch]);

    // Filter restaurants based on search query
    useEffect(() => {
        if (!searchQuery.trim()) {
            setFilteredRestaurants(restaurants);
            return;
        }

        const query = searchQuery.toLowerCase();
        const filtered = restaurants.filter(restaurant => {
            if (!restaurant) return false;

            const name = restaurant.name || '';
            const cuisine = restaurant.cuisine || '';
            const description = restaurant.description || '';

            return name.toLowerCase().includes(query) ||
                cuisine.toLowerCase().includes(query) ||
                description.toLowerCase().includes(query);
        });
        setFilteredRestaurants(filtered);
    }, [searchQuery, restaurants]);

    const handleSearch = (e) => {
        e.preventDefault();
        // No need to dispatch here as we're filtering locally
    };

    const handleRestaurantClick = (restaurantId) => {
        navigate(`/restaurant/${restaurantId}`);
    };

    return (
        <div className="search-page">
            <div className="search-header">
                <button className="back-button" onClick={() => navigate(-1)}>
                    <FaArrowLeft /> Back
                </button>
                <form onSubmit={handleSearch} className="search-form">
                    <div className="search-icon">
                        <FaArrowLeft />
                    </div>
                    <input
                        type="text"
                        className="search-input"
                        placeholder="Search restaurants..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </form>
            </div>

            <div className="search-results">
                {loading ? (
                    <div className="loading">Loading restaurants...</div>
                ) : error ? (
                    <div className="error-message">{error}</div>
                ) : filteredRestaurants.length === 0 ? (
                    <div className="no-results">
                        {searchQuery ? 'No restaurants found matching your search' : 'No restaurants available'}
                    </div>
                ) : (
                    <div className="restaurant-grid">
                        {filteredRestaurants.map((restaurant) => (
                            <div
                                key={restaurant._id}
                                className="restaurant-card"
                                onClick={() => handleRestaurantClick(restaurant._id)}
                            >
                                <img
                                    src={restaurant.image || 'https://via.placeholder.com/150'}
                                    alt={restaurant.name || 'Restaurant'}
                                    className="restaurant-image"
                                />
                                <div className="restaurant-info">
                                    <h3>{restaurant.name || 'Unnamed Restaurant'}</h3>
                                    <p>{restaurant.cuisine || 'Cuisine not specified'}</p>
                                    <div className="restaurant-meta">
                                        <span>⭐ {restaurant.rating || 'N/A'}</span>
                                        <span>🕒 {restaurant.timings || 'N/A'}</span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default SearchPage; 