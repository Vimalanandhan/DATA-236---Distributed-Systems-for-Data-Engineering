import React, { useState, useEffect } from 'react';
import { Form, Button, Container, Row, Col, Image, Alert } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { countryCodes, countryStateData } from '../../data/countryStateData';
import './CustomerProfile.css';

const CustomerProfile = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { user } = useSelector((state) => state.auth);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [successMessage, setSuccessMessage] = useState('');
    const [localCustomerData, setLocalCustomerData] = useState({
        name: '',
        email: '',
        country: '',
        state: '',
        profile_picture: null,
    });
    const [availableStates, setAvailableStates] = useState([]);

    // Function to navigate back
    const handleGoBack = () => {
        navigate(-1);
    };

    useEffect(() => {
        const fetchCustomerData = async () => {
            try {
                const response = await fetch(`/api/customers/${user.id}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                });

                if (!response.ok) {
                    throw new Error('Failed to fetch customer data');
                }

                const customerData = await response.json();
                console.log('Customer data:', customerData);

                setLocalCustomerData({
                    name: customerData.name || '',
                    email: customerData.email || '',
                    country: customerData.country || '',
                    state: customerData.state || '',
                    profile_picture: customerData.profile_picture || null,
                });
                setAvailableStates(countryStateData[customerData.country] || []);
                setLoading(false);
            } catch (err) {
                setError(err.message);
                setLoading(false);
            }
        };

        if (user && user.id) {
            fetchCustomerData();
        }
    }, [user]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setLocalCustomerData((prevState) => ({
            ...prevState,
            [name]: value,
        }));
        // Update available states when country changes
        if (name === 'country') {
            setAvailableStates(countryStateData[value] || []);
        }
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setLocalCustomerData({
            ...localCustomerData,
            profile_picture: file,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);
        setSuccessMessage('');

        const formData = new FormData();
        formData.append('name', localCustomerData.name);
        formData.append('email', localCustomerData.email);
        formData.append('country', localCustomerData.country);
        formData.append('state', localCustomerData.state);

        if (localCustomerData.profile_picture instanceof File) {
            formData.append('profile_picture', localCustomerData.profile_picture);
        }

        try {
            // Include Authorization header
            const token = localStorage.getItem('customerAuthToken'); // Assuming token is stored here
            if (!token) {
                setError('Authentication token not found. Please log in again.');
                return;
            }

            const headers = {
                'Authorization': `Bearer ${token}`
            };

            const response = await fetch(`/api/customers/profile`, {
                method: 'PUT',
                headers: headers, // Add headers here
                credentials: 'include', // Keep or remove based on backend CORS/cookie needs
                body: formData
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to update profile');
            }

            const updatedData = await response.json();
            setSuccessMessage('Profile updated successfully!');

            // Update the local state with the new data
            setLocalCustomerData({
                ...localCustomerData,
                profile_picture: updatedData.profile_picture || localCustomerData.profile_picture
            });
        } catch (err) {
            setError(err.message || 'Failed to update profile');
        }
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    if (!user) {
        return <div>Please log in to view your profile.</div>;
    }

    return (
        <Container className="profile-container">
            <h2>Customer Profile</h2>
            {error && <Alert variant="danger">{error}</Alert>}
            {successMessage && <Alert variant="success">{successMessage}</Alert>}
            <Form onSubmit={handleSubmit}>
                <Row>
                    <Col md={6}>
                        <Form.Group className="mb-3">
                            <Form.Label>Profile Picture</Form.Label>
                            <div className="profile-picture-container">
                                {localCustomerData.profile_picture ? (
                                    <Image
                                        src={
                                            localCustomerData.profile_picture instanceof File
                                                ? URL.createObjectURL(localCustomerData.profile_picture)
                                                : localCustomerData.profile_picture.startsWith('data:')
                                                    ? localCustomerData.profile_picture
                                                    : `data:image/jpeg;base64,${localCustomerData.profile_picture}`
                                        }
                                        alt="Profile"
                                        roundedCircle
                                        className="profile-picture"
                                    />
                                ) : (
                                    <div className="profile-picture-placeholder">
                                        {localCustomerData.name ? localCustomerData.name[0].toUpperCase() : '?'}
                                    </div>
                                )}
                                <Form.Control
                                    type="file"
                                    accept="image/*"
                                    onChange={handleImageChange}
                                    className="mt-2"
                                />
                            </div>
                        </Form.Group>
                    </Col>
                    <Col md={6}>
                        <Form.Group className="mb-3">
                            <Form.Label>Name</Form.Label>
                            <Form.Control
                                type="text"
                                name="name"
                                value={localCustomerData.name}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Email</Form.Label>
                            <Form.Control
                                type="email"
                                name="email"
                                value={localCustomerData.email}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>Country</Form.Label>
                            <Form.Select
                                name="country"
                                value={localCustomerData.country}
                                onChange={handleInputChange}
                                required
                            >
                                <option value="">Select a country</option>
                                {countryCodes.map((country) => (
                                    <option key={country.code} value={country.code}>
                                        {country.name}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                        <Form.Group className="mb-3">
                            <Form.Label>State</Form.Label>
                            <Form.Select
                                name="state"
                                value={localCustomerData.state}
                                onChange={handleInputChange}
                                required
                            >
                                <option value="">Select a state</option>
                                {availableStates.map((state) => (
                                    <option key={state.code} value={state.code}>
                                        {state.name}
                                    </option>
                                ))}
                            </Form.Select>
                        </Form.Group>
                    </Col>
                </Row>
                <div className="d-flex gap-2">
                    <Button variant="primary" type="submit">
                        Save Changes
                    </Button>
                    <Button variant="secondary" onClick={handleGoBack}>
                        Back
                    </Button>
                </div>
            </Form>
        </Container>
    );
};

export default CustomerProfile;
