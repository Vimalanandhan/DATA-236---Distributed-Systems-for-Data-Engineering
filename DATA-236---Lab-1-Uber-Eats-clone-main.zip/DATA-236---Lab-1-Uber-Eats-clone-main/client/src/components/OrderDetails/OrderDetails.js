import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { Container, Card, Button, Alert, Row, Col, ListGroup } from 'react-bootstrap';

const OrderDetails = () => {
    const { orderId } = useParams();
    const navigate = useNavigate();
    const { user } = useSelector((state) => state.auth);
    const [order, setOrder] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchOrderDetails = async () => {
            try {
                // Fetch order details
                const orderResponse = await fetch(`/api/orders/${orderId}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                });

                if (!orderResponse.ok) {
                    throw new Error('Failed to fetch order details');
                }

                const orderData = await orderResponse.json();
                console.log('Order data:', orderData);

                // Fetch restaurant details
                const restaurantResponse = await fetch(`/api/restaurants/${orderData.restaurant_id}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                });

                if (!restaurantResponse.ok) {
                    throw new Error('Failed to fetch restaurant details');
                }

                const restaurantData = await restaurantResponse.json();

                // Fetch customer details
                const customerResponse = await fetch(`/api/customers/${orderData.customer_id}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                });

                if (!customerResponse.ok) {
                    throw new Error('Failed to fetch customer details');
                }

                const customerData = await customerResponse.json();

                // Fetch dish details for each item
                const itemsWithDetails = await Promise.all(
                    orderData.items.map(async (item) => {
                        const dishResponse = await fetch(`/api/dishes/${item.dishId}`, {
                            method: 'GET',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                            credentials: 'include',
                        });

                        if (!dishResponse.ok) {
                            throw new Error('Failed to fetch dish details');
                        }

                        const dishData = await dishResponse.json();
                        return {
                            ...item,
                            dish: dishData
                        };
                    })
                );

                // Combine all data
                setOrder({
                    ...orderData,
                    restaurant: restaurantData,
                    customer: customerData,
                    items: itemsWithDetails
                });
            }
            } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    if (orderId) {
        fetchOrderDetails();
    }
}, [orderId]);

const handleGoBack = () => {
    navigate(-1);
};

if (!user) {
    return (
        <Container>
            <Alert variant="warning">Please log in to view order details.</Alert>
        </Container>
    );
}

if (loading) {
    return <Container>Loading...</Container>;
}

if (error) {
    return (
        <Container>
            <Alert variant="danger">{error}</Alert>
            <Button onClick={handleGoBack}>Go Back</Button>
        </Container>
    );
}

if (!order) {
    return (
        <Container>
            <Alert variant="info">Order not found.</Alert>
            <Button onClick={handleGoBack}>Go Back</Button>
        </Container>
    );
}

return (
    <Container className="order-details-container">
        <div className="d-flex justify-content-between align-items-center mb-4">
            <h2>Order Details</h2>
            <Button variant="secondary" onClick={handleGoBack}>
                Go Back
            </Button>
        </div>

        <Card className="mb-4">
            <Card.Header>
                <div className="d-flex justify-content-between align-items-center">
                    <span>Order #{order._id.slice(-6)}</span>
                    <span className={`status-badge ${order.status.toLowerCase()}`}>
                        {order.status}
                    </span>
                </div>
            </Card.Header>
            <Card.Body>
                <Row>
                    <Col md={4}>
                        <h5>Order Information</h5>
                        <p><strong>Order Date:</strong> {new Date(order.order_date).toLocaleString()}</p>
                        <p><strong>Status:</strong> {order.status}</p>
                        <p><strong>Total Amount:</strong> ${order.total_amount.toFixed(2)}</p>
                        <p><strong>Delivery Address:</strong> {order.delivery_address}</p>
                    </Col>
                    <Col md={4}>
                        <h5>Customer Information</h5>
                        <p><strong>Name:</strong> {order.customer?.name || 'N/A'}</p>
                        <p><strong>Email:</strong> {order.customer?.email || 'N/A'}</p>
                        <p><strong>Country:</strong> {order.customer?.country || 'N/A'}</p>
                        <p><strong>State:</strong> {order.customer?.state || 'N/A'}</p>
                    </Col>
                    <Col md={4}>
                        <h5>Restaurant Information</h5>
                        <p><strong>Restaurant:</strong> {order.restaurant?.name || 'N/A'}</p>
                        <p><strong>Email:</strong> {order.restaurant?.email || 'N/A'}</p>
                    </Col>
                </Row>
            </Card.Body>
        </Card>

        <Card>
            <Card.Header>
                <h5 className="mb-0">Order Items</h5>
            </Card.Header>
            <Card.Body>
                <ListGroup>
                    {order.items?.map((item) => (
                        <ListGroup.Item key={item._id}>
                            <div className="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6>{item.dish?.name || 'Unknown Item'}</h6>
                                    <p className="mb-0">Quantity: {item.quantity || 0}</p>
                                    <p className="mb-0">Price: ${(item.dish?.price || 0).toFixed(2)}</p>
                                </div>
                                <div>
                                    <strong>${((item.dish?.price || 0) * (item.quantity || 0)).toFixed(2)}</strong>
                                </div>
                            </div>
                        </ListGroup.Item>
                    ))}
                </ListGroup>
            </Card.Body>
        </Card>
    </Container>
);
};

export default OrderDetails; 