import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './RestaurantCard.css';

const RestaurantCard = ({ restaurant }) => {
  const [isFavorite, setIsFavorite] = useState(false);
  const defaultImage = 'https://img.freepik.com/free-photo/restaurant-interior_1127-3392.jpg';

  useEffect(() => {
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    setIsFavorite(favorites.includes(restaurant.id));
  }, [restaurant.id]);

  const handleFavoriteClick = (e) => {
    e.preventDefault();
    const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    if (isFavorite) {
      localStorage.setItem('favorites', JSON.stringify(favorites.filter(id => id !== restaurant.id)));
    } else {
      localStorage.setItem('favorites', JSON.stringify([...favorites, restaurant.id]));
    }
    setIsFavorite(!isFavorite);
  };
  console.log('RestaurantCard:', restaurant);

  return (
    <Link to={`/restaurant/${restaurant.id}`} className="restaurant-card">
      <img
        src={restaurant.image ? `data:image/jpeg;base64,${restaurant.image}` : defaultImage}
        alt={restaurant.name}
        onError={(e) => { e.target.src = defaultImage }}
      />
      <div className="restaurant-info">
        <div className="name-section">
          <h2>{restaurant.name}</h2>
          <button
            className={`favorite-btn ${isFavorite ? 'active' : ''}`}
            onClick={handleFavoriteClick}
            aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
          >
            <div className="heart"></div>
          </button>
        </div>
        <p className="cuisine">{restaurant.cuisine}</p>
        <div className="delivery-info">
          <span className="delivery-fee">
            ${restaurant.deliveryFee?.toFixed(2) || 'Free'} delivery
          </span>
          <span>•</span>
          <span className="min-order">
            ${restaurant.minimumOrder?.toFixed(2)} min
          </span>
        </div>
      </div>
    </Link>
  );
};

export default RestaurantCard;
