import { configureStore } from '@reduxjs/toolkit';
import customerReducer from '../features/customer/customerSlice'; //Correct Path

const store = configureStore({
    reducer: {
        customer: customerReducer,
    },
});

export default store;
