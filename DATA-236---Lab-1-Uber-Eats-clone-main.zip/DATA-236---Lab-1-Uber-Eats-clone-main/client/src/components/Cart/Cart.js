import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { clearCart, removeFromCart, decreaseQuantity, increaseQuantity, selectCartItems } from '../../store/slices/cartSlice';
import { Button, ListGroup, Container, Row, Col } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Cart.css';

const Cart = () => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const cartItems = useSelector(selectCartItems);
    const [deliveryAddress, setDeliveryAddress] = useState('');
    const { isAuthenticated, user } = useSelector(state => state.auth);

    useEffect(() => {
        const storedAddress = localStorage.getItem('deliveryAddress');
        if (storedAddress) {
            setDeliveryAddress(storedAddress);
        }
    }, []);

    const totalAmount = cartItems.reduce((sum, item) => sum + parseFloat(item.price) * item.quantity, 0);

    const handleRemoveFromCart = (itemId) => {
        dispatch(removeFromCart(itemId));
    };

    const handleDecreaseQuantity = (itemId) => {
        dispatch(decreaseQuantity(itemId));
    };

    const handleIncreaseQuantity = (itemId) => {
        dispatch(increaseQuantity(itemId));
    };

    const handlePlaceOrder = async () => {
        if (!isAuthenticated || !user) {
            alert("Please log in to place an order.");
            navigate('/login');
            return;
        }
        if (cartItems.length === 0) {
            alert("Your cart is empty.");
            return;
        }
        if (!deliveryAddress) {
            alert("Please enter a delivery address.");
            return;
        }

        const orderData = {
            customerId: user.id,
            restaurantId: cartItems[0]?.restaurant_id,
            items: cartItems.map((item) => ({ dishId: item.id, quantity: item.quantity })),
            totalAmount: parseFloat(totalAmount.toFixed(2)),
            deliveryAddress: deliveryAddress,
            status: 'New',
        };

        try {
            const response = await fetch('/api/orders', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${user.token}`
                },
                body: JSON.stringify(orderData),
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to create order');
            }

            const data = await response.json();
            alert(`Order placed successfully! Your order ID is: ${data.id}`);
            dispatch(clearCart());
            setDeliveryAddress('');
            navigate('/home');
        } catch (error) {
            console.error('Error placing order:', error);
            alert('Error placing order. Please try again.');
        }
    };

    const handleBackToMenu = () => {
        if (cartItems.length > 0) {
            navigate(-1);
        } else {
            navigate('/home');
        }
    };

    return (
        <Container className="cart-container">
            <h1>Your Cart</h1>
            {cartItems.length === 0 ? (
                <div className="text-center">
                    <p>Your cart is empty. Please add items from a restaurant.</p>
                    <Button variant="primary" onClick={() => navigate('/home')}>
                        Browse Restaurants
                    </Button>
                </div>
            ) : (
                <>
                    <ListGroup>
                        {cartItems.map((item) => (
                            <ListGroup.Item key={item.id} className="d-flex justify-content-between align-items-center">
                                <div>
                                    {item.image && (
                                        <img
                                            src={`data:image/jpeg;base64,${item.image}`}
                                            alt={item.name}
                                            style={{ width: '50px', height: '50px', marginRight: '10px' }}
                                        />
                                    )}
                                    <span>{item.name}</span>
                                    <span className="ms-3">${item.price}</span>
                                </div>
                                <div>
                                    <Button
                                        variant="outline-secondary"
                                        size="sm"
                                        onClick={() => handleDecreaseQuantity(item.id)}
                                        className="me-2"
                                    >
                                        -
                                    </Button>
                                    <span className="mx-2">{item.quantity}</span>
                                    <Button
                                        variant="outline-secondary"
                                        size="sm"
                                        onClick={() => handleIncreaseQuantity(item.id)}
                                        className="me-2"
                                    >
                                        +
                                    </Button>
                                    <Button
                                        variant="outline-danger"
                                        size="sm"
                                        onClick={() => handleRemoveFromCart(item.id)}
                                    >
                                        Remove
                                    </Button>
                                </div>
                            </ListGroup.Item>
                        ))}
                    </ListGroup>
                    <div className="mt-4">
                        <h3>Total: ${totalAmount.toFixed(2)}</h3>
                        <div className="mb-3">
                            <label htmlFor="deliveryAddress" className="form-label">Delivery Address</label>
                            <textarea
                                id="deliveryAddress"
                                className="form-control"
                                value={deliveryAddress}
                                onChange={(e) => setDeliveryAddress(e.target.value)}
                                rows="3"
                            />
                        </div>
                        <div className="d-flex gap-2">
                            <Button variant="primary" onClick={handlePlaceOrder}>
                                Place Order
                            </Button>
                            <Button variant="secondary" onClick={handleBackToMenu}>
                                Back to Menu
                            </Button>
                        </div>
                    </div>
                </>
            )}
        </Container>
    );
};

export default Cart;
