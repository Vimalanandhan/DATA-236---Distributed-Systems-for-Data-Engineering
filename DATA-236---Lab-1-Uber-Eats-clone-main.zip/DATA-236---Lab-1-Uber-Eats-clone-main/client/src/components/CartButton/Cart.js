import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Cart.css';

const Cart = ({ itemCount = 0 }) => {
  const navigate = useNavigate();

  const handleCartClick = () => {
    navigate('/cart');
  };

  return (
    <button className="cart-button" onClick={handleCartClick}>
      <span className="cart-icon">🛒</span>
      {itemCount > 0 && <span className="cart-count">{itemCount}</span>}
      <span>Cart</span>
    </button>
  );
};

export default Cart;