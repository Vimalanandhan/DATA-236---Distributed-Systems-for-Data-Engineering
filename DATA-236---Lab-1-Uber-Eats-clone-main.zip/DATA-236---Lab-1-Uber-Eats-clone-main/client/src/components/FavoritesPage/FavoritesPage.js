import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Alert, Spinner } from 'react-bootstrap'; // Added Alert, Spinner
import { useSelector } from 'react-redux'; // Import useSelector
import { selectIsAuthenticated, selectUser } from '../../store/slices/authSlice'; // Reverted import, we need to fix selection
import { FaHeart, FaRegHeart } from 'react-icons/fa'; // Import icons

// Assuming a RestaurantCard component or similar rendering logic
// import RestaurantCard from '../RestaurantCard/RestaurantCard'; 
import '../HomePage/HomePage.css'; // Reuse HomePage styles for grid/card

const FavoritesPage = () => {
    const [favoriteRestaurants, setFavoriteRestaurants] = useState([]);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    // --- FIX: Select state correctly --- 
    const isAuthenticated = useSelector(state => state.auth.isAuthenticated);
    const token = useSelector(state => state.auth.token); // Select token separately
    // -----------------------------------

    // --- Log state --- 
    console.log('[FavoritesPage] Rendering - State:', { favoriteRestaurants, loading, error, isAuthenticated, tokenExists: !!token });
    // -----------------

    // Function to navigate back
    const handleGoBack = () => {
        navigate(-1);
    };

    // --- Fetch Favorites from API --- 
    const fetchFavorites = async () => {
        if (!isAuthenticated || !token) {
            setLoading(false);
            setFavoriteRestaurants([]);
            return;
        }
        setLoading(true);
        setError(null);
        try {
            const response = await fetch('/api/favorites', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            if (response.ok) {
                const data = await response.json();
                // --- Log received data --- 
                console.log('[FavoritesPage] fetchFavorites - Received data:', data);
                // -------------------------
                setFavoriteRestaurants(data);
            } else {
                console.error('Failed to fetch favorites:', response.status);
                if (response.status === 401) {
                    setError('Authentication failed. Please log in again.');
                } else {
                    setError('Failed to load favorites. Please try again.');
                }
                setFavoriteRestaurants([]);
            }
        } catch (err) {
            console.error('Error fetching favorites:', err);
            setError('An error occurred while fetching favorites.');
            setFavoriteRestaurants([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        // Fetch only when authenticated and token is available
        if (isAuthenticated && token) {
            fetchFavorites();
        } else if (!isAuthenticated) {
            // Explicitly handle the case where user logs out while on the page
            setLoading(false);
            setFavoriteRestaurants([]);
        }
        // We still depend on these to refetch if login/logout happens
    }, [isAuthenticated, token]);

    // --- Toggle Favorite Handler (Similar to HomePage) ---
    const handleToggleFavorite = async (restaurantId) => {
        if (!isAuthenticated || !token) {
            navigate('/login');
            return;
        }
        const method = 'DELETE';
        const url = `/api/favorites/${restaurantId}`;
        const headers = { 'Authorization': `Bearer ${token}` };

        const originalFavorites = [...favoriteRestaurants];
        setFavoriteRestaurants(prev => prev.filter(r => r._id !== restaurantId));
        setError(null); // Clear previous errors optimistically

        try {
            const response = await fetch(url, { method, headers });
            if (!response.ok) {
                console.error('Failed to remove favorite:', response.status);
                setFavoriteRestaurants(originalFavorites);
                setError('Failed to remove favorite. Please try again.');
            } else {
                console.log('Favorite removed successfully:', restaurantId);
            }
        } catch (err) {
            console.error('Error removing favorite:', err);
            setFavoriteRestaurants(originalFavorites);
            setError('An error occurred. Please try again.');
        }
    };
    // -------------------------------------------------

    // Helper to get image URL (copied from HomePage for consistency)
    const getImageUrl = (restaurant) => {
        if (!restaurant?.image) return 'https://via.placeholder.com/300x200';
        if (restaurant.image.startsWith('data:image')) return restaurant.image;
        if (restaurant.image.startsWith('http')) return restaurant.image;
        if (restaurant.image.length > 500) { // Basic check if it looks like base64
            return `data:image/jpeg;base64,${restaurant.image}`;
        }
        // Fallback if it's an unexpected path format?
        return 'https://via.placeholder.com/300x200';
    };

    return (
        <div style={{ padding: '20px' }}>
            <div className="d-flex justify-content-between align-items-center mb-3">
                <h1>Favorite Restaurants</h1>
                <Button variant="secondary" onClick={handleGoBack}>
                    Go Back
                </Button>
            </div>

            {loading && (
                <div className="text-center"><Spinner animation="border" /> <p>Loading Favorites...</p></div>
            )}

            {error && <Alert variant="danger">{error}</Alert>}

            {!loading && !isAuthenticated && (
                <Alert variant="warning">Please log in to view your favorite restaurants.</Alert>
            )}

            {!loading && isAuthenticated && favoriteRestaurants.length === 0 && !error && (
                <Alert variant="info">You haven't added any favorite restaurants yet.</Alert>
            )}

            {!loading && favoriteRestaurants.length > 0 && (
                // Reuse grid styles from HomePage.css
                <div className="restaurant-grid">
                    {favoriteRestaurants.map((restaurant) => (
                        // --- Render using structure similar to HomePage --- 
                        <div
                            key={restaurant._id}
                            className="restaurant-card"
                            onClick={() => navigate(`/restaurant/${restaurant._id}`)} // Navigate on card click
                        >
                            <div className="restaurant-image-container">
                                <img
                                    src={getImageUrl(restaurant)}
                                    alt={restaurant.name || 'Restaurant'}
                                    className="restaurant-image"
                                    onError={(e) => { e.target.src = 'https://via.placeholder.com/300x200'; }}
                                />
                                {/* Favorite Button (Always filled, click to remove) */}
                                <button
                                    className={`favorite-btn favorited`}
                                    style={{ position: 'absolute', top: '10px', right: '10px', background: 'rgba(255,255,255,0.7)', border: 'none', borderRadius: '50%', padding: '5px', cursor: 'pointer' }} // Basic inline style
                                    onClick={(e) => {
                                        e.stopPropagation(); // Prevent card click
                                        handleToggleFavorite(restaurant._id);
                                    }}
                                >
                                    <FaHeart style={{ color: 'red' }} />
                                </button>
                            </div>
                            <div className="restaurant-info">
                                <h3>{restaurant.name || 'Unnamed Restaurant'}</h3>
                                <div className="restaurant-meta">
                                    {/* Display other relevant info like cuisine/time if available */}
                                    <span className="cuisine">{restaurant.cuisine || 'Cuisine N/A'}</span>
                                    <span className="delivery-time">🕒 {restaurant.timings || 'N/A'}</span>
                                </div>
                                <p className="restaurant-description">
                                    {restaurant.description || 'No description available'}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}
export default FavoritesPage;
