import React, { useState, useEffect } from 'react';
import { Card, Button, Alert, Container, Row, Col } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import './CustomerOrders.css'; // Import CSS for styling (make sure this file exists)

const CustomerOrders = () => {
    const [orders, setOrders] = useState([]);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const { user } = useSelector((state) => state.auth);

    useEffect(() => {
        const fetchOrders = async () => {
            try {
                const response = await fetch(`/api/orders/customer/${user.id}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include', // Send cookies with the request
                });

                if (!response.ok) {
                    if (response.status === 401) {
                        throw new Error('Unauthorized: Please log in again.');
                    } else {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                }
                // If response is OK, parse JSON
                const data = await response.json();
                // console.log('[CustomerOrders] API Response Data:', data); // Removed log
                setOrders(data);

            } catch (err) { // Catch block for fetch errors
                console.error('Error fetching orders:', err); // Log the actual error
                setError(err.message);
            }
        }; // End of fetchOrders function definition

        // Check if customer and customer.id exist before fetching
        if (user && user.id) {
            fetchOrders();
        }
    }, [user]); // End of useEffect hook dependencies
    const handleGoBack = () => {
        navigate(-1); // Navigate to the home page
    };

    const handleCancelOrder = async (orderId) => {
        try {
            console.log('Cancelling order:', orderId);
            const response = await fetch(`/api/orders/${orderId}/cancel`, {
                method: 'PUT', // You're updating, so use PUT
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include', // Send cookies with the request
            });
            console.log('Cancel API Response:', response);


            if (!response.ok) {
                const errorData = await response.json(); // Try to parse error data
                throw new Error(`Failed to cancel order: ${errorData.error || response.statusText}`); // Use detailed error message
            }

            const data = await response.json();
            console.log('Order cancelled successfully:', data);
            setOrders(prevOrders =>
                prevOrders.map(order =>
                    order._id === orderId ? { ...order, status: 'Cancelled' } : order // Compare using _id
                )
            );

        } catch (error) {
            console.error('Error cancelling order:', error);
            // Handle the error appropriately - display an error message to the user.
            alert('Failed to cancel order. Please try again.'); //Or display in a better way.
        }
    };

    if (!user) {
        return (
            <Container>
                <Alert variant="warning">Please log in to view your orders.</Alert>
            </Container>
        );
    }

    return (
        <Container className="customer-orders-container">
            <div className="header-section">
                <h2>Your Orders</h2>
                <Button onClick={handleGoBack} className="go-back-button">
                    Go Back
                </Button>
            </div>
            {error && <Alert variant="danger">{error}</Alert>}
            {!error && orders.length === 0 && (
                <Alert variant="info">You haven't placed any orders yet.</Alert>
            )}
            {!error && orders.length > 0 && (
                <Row xs={1} md={2} lg={3} className="g-4">
                    {orders.map((order) => (
                        <Col key={order._id}> {/* Key uses correct _id */}
                            <Card className="order-card">
                                <Card.Header>
                                    <div className="d-flex justify-content-between align-items-center">
                                        <span>Order #{order._id.slice(-6)}</span>
                                        <span className={`status-badge ${order.status.toLowerCase()}`}>
                                            {order.status}
                                        </span>
                                    </div>
                                </Card.Header>
                                <Card.Body>
                                    <Card.Text>
                                        <strong>Date:</strong> {order.order_date ? new Date(order.order_date).toLocaleDateString() : 'N/A'}
                                    </Card.Text>
                                    <Card.Text>
                                        <strong>Total:</strong> ${(order.total_amount || 0).toFixed(2)}
                                    </Card.Text>
                                    <Card.Text>
                                        <strong>Items:</strong> {order.items?.length || 0}
                                    </Card.Text>
                                </Card.Body>
                                <Card.Footer>
                                    <div className="d-flex justify-content-between">
                                        <Button
                                            variant="outline-primary"
                                            onClick={() => navigate(`/customer/orders/${order._id}`)}
                                        >
                                            View Details
                                        </Button>
                                        {order.status === 'Pending' && (
                                            <Button
                                                variant="outline-danger"
                                                onClick={() => handleCancelOrder(order._id)}
                                            >
                                                Cancel Order
                                            </Button>
                                        )}
                                    </div>
                                </Card.Footer>
                            </Card>
                        </Col>
                    ))}
                </Row>
            )}
        </Container>
    );
};

export default CustomerOrders;
