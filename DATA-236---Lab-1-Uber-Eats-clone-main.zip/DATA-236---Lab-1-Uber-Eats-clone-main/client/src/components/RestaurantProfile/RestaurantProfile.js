import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Form, Button, Card, Alert, Spinner, Dropdown, Tabs, Tab } from 'react-bootstrap';
import Modal from 'react-bootstrap/Modal';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../../features/cart/cartSlice';
import { fetchCustomer, updateCustomerProfile } from '../../features/customer/customerSlice';
import { countryCodes, countryStateData } from '../../data/countryStateData';

const RestaurantProfile = () => {
  const navigate = useNavigate();

  // --- Authentication Check Effect ---
  useEffect(() => {
    const token = localStorage.getItem('restaurantAuthToken');
    if (!token) {
      console.log('[RestaurantProfile] No token found, redirecting to login.');
      navigate('/restaurant/login', { replace: true });
    }
    // We can keep the dependency array empty [] so this check runs only once on mount,
    // or add other dependencies if the auth state might change dynamically
    // while the component is mounted (though logout usually involves navigation away).
  }, [navigate]);
  // ----------------------------------

  const DISH_CATEGORIES = [
    'Appetizers',
    'Main Course',
    'Desserts',
    'Beverages',
    'Sides',
    'Salads',
    'Soups',
    'Specials'
  ];

  const ORDER_STATUSES = [
    'New',
    'Order Received',
    'Preparing',
    'On the Way',
    'Pick-up Ready',
    'Delivered',
    'Picked Up',
    'Cancelled',
  ];

  // States
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);
  const [editImagePreview, setEditImagePreview] = useState(null);
  const [profileImage, setProfileImage] = useState(null);
  const [profileImagePreview, setProfileImagePreview] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [selectedOrderStatus, setSelectedOrderStatus] = useState('All');
  const [customerProfiles, setCustomerProfiles] = useState({});
  const [showCustomerProfile, setShowCustomerProfile] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showCustomerProfileModal, setShowCustomerProfileModal] = useState(false);
  const [restaurantId, setRestaurantId] = useState(null);
  const [showAddDishForm, setShowAddDishForm] = useState(false);
  const [showRestaurantProfile, setShowRestaurantProfile] = useState(false);

  // Profile State
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    location: '',
    cuisine: '',
    description: '',
    contact_info: '',
    timings: '',
    image: null
  });

  const CUISINE_OPTIONS = [
    'Italian',
    'Chinese',
    'Japanese',
    'Indian',
    'Mexican',
    'American',
    'Thai',
    'Mediterranean',
    'Other'
  ];

  // Auth Check
  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    console.log('Checking Auth');
    try {
      const token = localStorage.getItem('restaurantAuthToken');
      if (!token) {
        throw new Error('No auth token found');
      }

      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const response = await fetch(`${apiUrl}/auth/restaurant/me`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      console.log('Response from /api/auth/restaurant/me:', response);

      if (!response.ok) {
        if (response.status === 401) {
          localStorage.removeItem('restaurantAuthToken');
          throw new Error('Not authenticated');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('Auth check successful, restaurant data:', data);
      setRestaurantId(data.id);
      setIsAuthenticated(true);
    } catch (err) {
      console.error('Auth check failed:', err);
      localStorage.removeItem('restaurantAuthToken');
      navigate('/restaurant/login', { replace: true });
    } finally {
      setIsLoading(false);
    }
  };

  // Refactored: Fetch profile/dishes only when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      fetchProfile();
      fetchDishes();
    }
  }, [isAuthenticated]); // Re-run when isAuthenticated changes

  // Image Handlers
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        setNewDish(prev => ({ ...prev, image: file }));
        setImagePreview(URL.createObjectURL(file));
      } else {
        setError('Please select an image file');
      }
    }
  };

  const handleEditImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        setEditForm(prev => ({ ...prev, image: file }));
        setEditImagePreview(URL.createObjectURL(file));
      } else {
        setError('Please select an image file');
      }
    }
  };

  const handleProfileImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        setProfileImage(file);
        setProfileImagePreview(URL.createObjectURL(file));
      } else {
        setError('Please select an image file');
      }
    }
  };

  const [dishes, setDishes] = useState([]);
  const [newDish, setNewDish] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    ingredients: '',
    image: null
  });
  const [editingDish, setEditingDish] = useState(null);
  const [editForm, setEditForm] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    ingredients: ''
  });

  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    return () => {
      if (imagePreview) URL.revokeObjectURL(imagePreview);
      if (editImagePreview) URL.revokeObjectURL(editImagePreview);
    };
  }, [imagePreview, editImagePreview]);

  const handleEditClick = (dish) => {
    setEditingDish(dish.id);
    setEditForm({
      name: dish.name,
      description: dish.description,
      price: dish.price,
      category: dish.category,
      ingredients: dish.ingredients,
      image: null
    });
    setEditImagePreview(null);
  };

  const handleUpdateDish = async (dishId) => {
    try {
      const formData = new FormData();
      formData.append('name', editForm.name);
      formData.append('description', editForm.description);
      formData.append('price', editForm.price);
      formData.append('category', editForm.category);
      formData.append('ingredients', editForm.ingredients);
      if (editForm.image instanceof File) {
        formData.append('image', editForm.image);
      }

      const token = localStorage.getItem('restaurantAuthToken');
      if (!token) {
        throw new Error('No auth token found');
      }

      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const response = await fetch(`${apiUrl}/dishes/${dishId}`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('Dish updated successfully:', data);
      setDishes(dishes.map(dish => dish.id === dishId ? data : dish));
      setEditingDish(null);
      setEditImagePreview(null);
      setSuccessMessage('Dish updated successfully');
    } catch (err) {
      console.error('Update dish error:', err);
      setError(err.message || 'Failed to update dish');
    }
  };

  const fetchProfile = async () => {
    try {
      const token = localStorage.getItem('restaurantAuthToken');
      const headers = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      } else {
        console.warn('No auth token found for fetchProfile');
        setError('Authentication required to fetch profile.');
        return;
      }

      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const response = await fetch(`${apiUrl}/restaurants/profile`, {
        headers
      });
      if (response.ok) {
        const data = await response.json();
        setProfile(data);
        setRestaurantId(data.id);
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to fetch profile');
        if (response.status === 401) {
          localStorage.removeItem('restaurantAuthToken');
          navigate('/restaurant/login');
        }
      }
    } catch (err) {
      setError('Network error occurred while fetching profile');
      console.error('fetchProfile error:', err);
    }
  };

  const fetchDishes = async () => {
    try {
      const token = localStorage.getItem('restaurantAuthToken');
      if (!token) {
        throw new Error('No auth token found');
      }

      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const response = await fetch(`${apiUrl}/restaurants/dishes`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      setDishes(data);
    } catch (err) {
      console.error('Error fetching dishes:', err);
      setError(err.message || 'Failed to fetch dishes');
    }
  };

  const fetchOrders = async () => {
    setLoadingOrders(true);
    try {
      const token = localStorage.getItem('restaurantAuthToken');
      const headers = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      } else {
        console.warn('No auth token found for fetchOrders');
        setError('Authentication required to fetch orders.');
        setLoadingOrders(false);
        return;
      }

      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const response = await fetch(`${apiUrl}/orders`, {
        method: 'GET',
        headers
      });

      if (!response.ok) {
        if (response.status === 401) {
          localStorage.removeItem('restaurantAuthToken');
          navigate('/restaurant/login');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('Fetched Orders from Backend:', data);
      setOrders(data);
    } catch (error) {
      console.error('Error fetching orders:', error);
      setError('Error fetching orders');
    } finally {
      setLoadingOrders(false);
    }
  };

  const fetchCustomerProfile = async (customerId) => {
    try {
      // --- FIX: Add Authorization Header --- 
      const token = localStorage.getItem('restaurantAuthToken'); // Assuming restaurant needs to be authed to view customer
      const headers = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      } else {
        console.error('Fetch Customer Profile Error: No auth token found.');
        // Handle missing token - maybe just log, or show limited info?
        setError('Authentication required to view customer details.');
        return;
      }
      // ------------------------------------

      const response = await fetch(`/api/customers/${customerId}`, {
        method: 'GET',
        headers // Use prepared headers
        // Removed credentials: 'include'
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setCustomerProfiles((prevProfiles) => ({
        ...prevProfiles,
        [customerId]: data,
      }));
      console.log('Customer Profile:', data);
    } catch (error) {
      console.error('Error fetching customer profile:', error);
    }
  };

  const handleViewCustomerProfile = (customerId) => {
    setSelectedCustomer(customerId);
    if (!customerProfiles[customerId]) {
      fetchCustomerProfile(customerId);
    }
    setShowCustomerProfileModal(true); // Show the modal
  };

  const handleCloseCustomerProfileModal = () => setShowCustomerProfileModal(false); // Close modal function

  const toggleAddDishForm = () => {
    setShowAddDishForm(prevShowAddDishForm => !prevShowAddDishForm);
  };

  const toggleRestaurantProfile = () => {
    setShowRestaurantProfile(prevShowRestaurantProfile => !prevShowRestaurantProfile);
  };

  const handleLogout = async () => {
    setError(null); // Clear previous errors
    try {
      const response = await fetch('/api/auth/restaurant/logout', {
        method: 'POST',
        // Consider sending Authorization header if backend expects it for logout
        // headers: { 'Authorization': `Bearer ${localStorage.getItem('restaurantAuthToken')}` }
        // credentials: 'include' // Keep if backend relies on cookie for logout endpoint access
      });

      if (!response.ok) {
        // Log error but proceed with client-side cleanup
        console.error('Backend restaurant logout failed:', response.status);
        // throw new Error('Logout failed'); // Maybe don't throw, just proceed
      }
      console.log('Backend restaurant logout called successfully (or failed gracefully).');

    } catch (error) {
      console.error('Logout API call error:', error);
      // Don't necessarily set component error state, as we are navigating away
      // setError('Failed to logout cleanly from backend, but proceeding with client cleanup.');
    } finally {
      // --- Ensure localStorage is cleared --- 
      console.log('Clearing restaurantAuthToken from localStorage.');
      localStorage.removeItem('restaurantAuthToken');
      // --------------------------------------

      // Redirect to login page
      console.log('Navigating to /restaurant/login.');
      navigate('/restaurant/login');
    }
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    setIsLoading(true);

    try {
      const formData = new FormData();
      formData.append('name', profile.name);
      formData.append('email', profile.email);
      formData.append('location', profile.location);
      formData.append('cuisine', profile.cuisine);
      formData.append('description', profile.description);
      formData.append('contact_info', profile.contact_info);
      formData.append('timings', profile.timings);

      if (profileImage) {
        formData.append('image', profileImage);
      }

      const token = localStorage.getItem('restaurantAuthToken');
      const headers = {}; // No Content-Type for FormData
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      } else {
        console.error('Update Profile Error: No auth token found.');
        setError('Authentication required to update profile.');
        setIsLoading(false);
        return;
      }

      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const response = await fetch(`${apiUrl}/restaurants/profile`, {
        method: 'PUT',
        headers,
        body: formData
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update profile');
      }

      setSuccessMessage('Profile updated successfully');
      fetchProfile();
    } catch (err) {
      console.error('Update profile error:', err);
      setError('Failed to update profile: ' + err.message);
      if (err.message.includes('401')) {
        localStorage.removeItem('restaurantAuthToken');
        navigate('/restaurant/login');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateOrderStatus = async (orderId, newStatus) => {
    setError(''); // Clear previous errors
    setSuccessMessage('');
    if (!orderId) {
      console.error('Update Order Status Error: orderId is undefined');
      setError('Cannot update order: Order ID is missing.');
      return;
    }
    try {
      // --- FIX: Add Authorization Header --- 
      const token = localStorage.getItem('restaurantAuthToken');
      const headers = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      } else {
        console.error('Update Order Status Error: No auth token found.');
        setError('Authentication required to update order status.');
        return;
      }
      // ------------------------------------

      const response = await fetch(`/api/orders/${orderId}`, {
        method: 'PUT',
        headers, // Use prepared headers
        // Removed credentials: 'include'
        body: JSON.stringify({ status: newStatus })
      });

      if (response.ok) {
        setSuccessMessage(`Order ${orderId} status updated to ${newStatus}`);
        fetchOrders(); // Refresh orders
      } else {
        const errorData = await response.json();
        setError(errorData.error || `Failed to update order status for order ${orderId}`);
      }
    } catch (error) {
      console.error('Error updating order status:', error);
      setError(`Error updating order status for order ${orderId}`);
    }
  };

  const handleAddDish = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('restaurantAuthToken');
      if (!token) {
        throw new Error('No auth token found');
      }

      const formData = new FormData();
      formData.append('name', newDish.name);
      formData.append('description', newDish.description);
      formData.append('price', newDish.price);
      formData.append('category', newDish.category);
      formData.append('ingredients', newDish.ingredients);
      if (newDish.image instanceof File) {
        formData.append('image', newDish.image);
      }

      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const response = await fetch(`${apiUrl}/dishes`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('Dish added successfully:', data);
      setDishes([...dishes, data]);
      setNewDish({
        name: '',
        description: '',
        price: '',
        category: '',
        ingredients: '',
        image: null
      });
      setImagePreview(null);
      setSuccessMessage('Dish added successfully');
    } catch (err) {
      console.error('Add dish error:', err);
      setError(err.message || 'Failed to add dish');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleDishInputChange = (e) => {
    const { name, value } = e.target;
    setNewDish(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleOrderStatusFilterChange = (status) => {
    setSelectedOrderStatus(status);
  };

  const filteredOrders = selectedOrderStatus === 'All'
    ? orders
    : orders.filter(order => order.status === selectedOrderStatus);

  // --- Add handler for Tab selection --- 
  const handleTabSelect = (key) => {
    if (key === 'orders') {
      // Fetch orders only when the orders tab is selected
      // Consider adding a check to prevent re-fetching if orders are already loaded
      // if (orders.length === 0) { 
      fetchOrders();
      // }
    }
    // Add logic for other tabs if needed
  };
  // -----------------------------------

  return (
    <Container className="py-5">
      {error && <Alert variant="danger">{error}</Alert>}
      {successMessage && <Alert variant="success">{successMessage}</Alert>}

      <Row className="mb-3">
        <Col className='d-flex justify-content-end'>
          <Button variant="danger" onClick={handleLogout}>
            Sign Out
          </Button>
        </Col>
      </Row>

      <Tabs defaultActiveKey="profile" id="restaurant-tabs" className="mb-3" onSelect={handleTabSelect}>
        <Tab eventKey="profile" title="Restaurant Profile">
          <Row className="mb-5">
            <Col md={8}>
              <h2 className="mb-4">Restaurant Profile</h2>
              <Form onSubmit={handleUpdateProfile}>
                <Form.Group className="mb-3">
                  <Form.Label>Restaurant Image</Form.Label>
                  <Form.Control
                    type="file"
                    accept="image/*"
                    onChange={handleProfileImageChange}
                  />
                  {profileImagePreview && (
                    <div className="mt-2">
                      <img
                        src={profileImagePreview}
                        alt="Restaurant Preview"
                        style={{
                          maxWidth: '200px',
                          maxHeight: '200px',
                          objectFit: 'contain'
                        }}
                      />
                    </div>
                  )}
                  {profile.image && !profileImagePreview && (
                    <div className="mt-2">
                      <img
                        src={`data:image/jpeg;base64,${profile.image}`}
                        alt="Current Restaurant"
                        style={{
                          maxWidth: '200px',
                          maxHeight: '200px',
                          objectFit: 'contain'
                        }}
                      />
                    </div>
                  )}
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Restaurant Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    value={profile.name}
                    onChange={handleInputChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Email</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    value={profile.email}
                    onChange={handleInputChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Cuisine Type</Form.Label>
                  <Form.Select
                    name="cuisine"
                    value={profile.cuisine}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Select Cuisine</option>
                    {CUISINE_OPTIONS.map((cuisine) => (
                      <option key={cuisine} value={cuisine}>
                        {cuisine}
                      </option>
                    ))}
                  </Form.Select>
                </Form.Group>

                {/* Display Restaurant ID */}
                {restaurantId && (
                  <Form.Group className="mb-3">
                    <Form.Label>Restaurant ID</Form.Label>
                    <Form.Control type="text" value={restaurantId} readOnly />
                  </Form.Group>
                )}

                <Form.Group className="mb-3">
                  <Form.Label>Location</Form.Label>
                  <Form.Control
                    type="text"
                    name="location"
                    value={profile.location}
                    onChange={handleInputChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    as="textarea"
                    name="description"
                    value={profile.description}
                    onChange={handleInputChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Contact Info</Form.Label>
                  <Form.Control
                    type="text"
                    name="contact_info"
                    value={profile.contact_info}
                    onChange={handleInputChange}
                    required
                  />
                </Form.Group>

                <Form.Group className="mb-3">
                  <Form.Label>Timings</Form.Label>
                  <Form.Control
                    type="text"
                    name="timings"
                    value={profile.timings}
                    onChange={handleInputChange}
                    required
                  />
                </Form.Group>

                <Button variant="primary" type="submit">
                  Update Profile
                </Button>
              </Form>
            </Col>
          </Row>
        </Tab>
        <Tab eventKey="orders" title="Orders">
          <div>
            <h3>Orders</h3>
            <Dropdown>
              <Dropdown.Toggle variant="secondary" id="order-status-dropdown">
                Filter by Status: {selectedOrderStatus}
              </Dropdown.Toggle>
              <Dropdown.Menu>
                <Dropdown.Item onClick={() => handleOrderStatusFilterChange('All')}>All</Dropdown.Item>
                {ORDER_STATUSES.map(status => (
                  <Dropdown.Item key={status} onClick={() => handleOrderStatusFilterChange(status)}>
                    {status}
                  </Dropdown.Item>
                ))}
              </Dropdown.Menu>
            </Dropdown>
            {loadingOrders ? (
              <Spinner animation="border" />
            ) : filteredOrders.length > 0 ? (
              <Row xs={1} md={2} lg={3} className="g-4">
                {filteredOrders.map(order => (
                  <Col key={order._id || order.id}>
                    <Card className="mb-3">
                      <Card.Body>
                        <Card.Title>Order ID: {order._id || order.id}</Card.Title>
                        <div>
                          <b>Items:</b>
                          <ul>
                            {order.items &&
                              order.items.map((item, index) => (
                                <li key={`${item.dishId?._id}-${index}`}>
                                  {item.dishId?.name || "Dish name not found"} (Qty: {item.quantity})
                                </li>
                              ))}
                          </ul>
                        </div>
                        <Card.Text>
                          Status: {order.status}
                        </Card.Text>
                        <Button variant='link' onClick={() => handleViewCustomerProfile(order.customer_id?._id)}>View Customer Profile</Button>
                        <Dropdown className='d-inline-block ms-2'>
                          <Dropdown.Toggle variant="primary" id={`order-status-dropdown-${order._id || order.id}`}>
                            Update Status
                          </Dropdown.Toggle>
                          <Dropdown.Menu>
                            {ORDER_STATUSES.map((status) => (
                              <Dropdown.Item
                                key={status}
                                onClick={() => handleUpdateOrderStatus(order._id || order.id, status)}
                              >
                                {status}
                              </Dropdown.Item>
                            ))}
                          </Dropdown.Menu>
                        </Dropdown>
                      </Card.Body>
                    </Card>
                  </Col>
                ))}
              </Row>
            ) : (
              <p>No orders found.</p>
            )}
          </div>
        </Tab>
        <Tab eventKey="addDish" title="Add Dish">
          <Row className="mb-5">
            <Col>
              <h3 className="mb-4">Add New Dish</h3>
              <Form onSubmit={handleAddDish}>
                <Form.Group className="mb-3">
                  <Form.Label>Dish Image</Form.Label>
                  <Form.Control
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                  />
                  {imagePreview && (
                    <div className="mt-2">
                      <img
                        src={imagePreview}
                        alt="Dish Preview"
                        style={{ maxWidth: '200px', maxHeight: '200px', objectFit: 'contain' }}
                      />
                    </div>
                  )}
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    value={newDish.name}
                    onChange={handleDishInputChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Description</Form.Label>
                  <Form.Control
                    as="textarea"
                    name="description"
                    value={newDish.description}
                    onChange={handleDishInputChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Price</Form.Label>
                  <Form.Control
                    type="number"
                    name="price"
                    value={newDish.price}
                    onChange={handleDishInputChange}
                    required
                  />
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Category</Form.Label>
                  <Form.Select
                    name="category"
                    value={newDish.category}
                    onChange={handleDishInputChange}
                    required
                  >
                    <option value="">Select a category</option>
                    {DISH_CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </Form.Select>
                </Form.Group>
                <Form.Group className="mb-3">
                  <Form.Label>Ingredients</Form.Label>
                  <Form.Control
                    type="text"
                    name="ingredients"
                    value={newDish.ingredients}
                    onChange={handleDishInputChange}
                    required
                  />
                </Form.Group>
                <Button variant="primary" type="submit">
                  Add Dish
                </Button>
              </Form>
            </Col>
          </Row>
        </Tab>
        <Tab eventKey="dishes" title="Restaurant Dishes">
          <Row>
            <Col>
              <h3 className="mb-4">Restaurant Dishes</h3>
              {isLoading ? (
                <div className="text-center">
                  <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </Spinner>
                </div>
              ) : dishes.length > 0 ? (
                <Row xs={1} md={2} lg={3} className="g-4">
                  {dishes.map(dish => (
                    <Col key={dish.id}>
                      <Card>
                        {dish.image && (
                          <Card.Img
                            variant="top"
                            src={`data:image/jpeg;base64,${dish.image}`}
                            alt={dish.name}
                            style={{
                              height: '200px',
                              objectFit: 'cover',
                              borderBottom: '1px solid #dee2e6'
                            }}
                          />
                        )}
                        <Card.Body>
                          {editingDish === dish.id ? (
                            <Form onSubmit={(e) => {
                              e.preventDefault();
                              handleUpdateDish(dish.id);
                            }}>
                              <Form.Group className="mb-3">
                                <Form.Label>Name</Form.Label>
                                <Form.Control
                                  type="text"
                                  value={editForm.name}
                                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                                  required
                                />
                              </Form.Group>

                              <Form.Group className="mb-3">
                                <Form.Label>Description</Form.Label>
                                <Form.Control
                                  as="textarea"
                                  value={editForm.description}
                                  onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                                  required
                                />
                              </Form.Group>

                              <Form.Group className="mb-3">
                                <Form.Label>Price</Form.Label>
                                <Form.Control
                                  type="number"
                                  step="0.01"
                                  value={editForm.price}
                                  onChange={(e) => setEditForm({ ...editForm, price: e.target.value })}
                                  required
                                />
                              </Form.Group>

                              <Form.Group className="mb-3">
                                <Form.Label>Category</Form.Label>
                                <Form.Select
                                  value={editForm.category}
                                  onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                                  required
                                >
                                  <option value="">Select Category</option>
                                  {DISH_CATEGORIES.map(category => (
                                    <option key={category} value={category}>
                                      {category}
                                    </option>
                                  ))}
                                </Form.Select>
                              </Form.Group>
                              <Form.Group className="mb-3">
                                <Form.Label>Dish Image</Form.Label>
                                <Form.Control
                                  type="file"
                                  accept="image/*"
                                  onChange={handleEditImageChange}
                                />
                                {editImagePreview ? (
                                  <div className="mt-2">
                                    <p>New Image Preview:</p>
                                    <img
                                      src={editImagePreview}
                                      alt="New Preview"
                                      style={{
                                        maxWidth: '200px',
                                        maxHeight: '200px',
                                        objectFit: 'contain'
                                      }}
                                    />
                                  </div>
                                ) : dish.image && (
                                  <div className="mt-2">
                                    <p>Current Image:</p>
                                    <img
                                      src={`data:image/jpeg;base64,${dish.image}`}
                                      alt="Current"
                                      style={{
                                        maxWidth: '200px',
                                        maxHeight: '200px',
                                        objectFit: 'contain'
                                      }}
                                    />
                                  </div>
                                )}
                              </Form.Group>
                              <div className="d-flex gap-2">
                                <Button variant="success" type="submit">
                                  Save
                                </Button>
                                <Button variant="secondary" onClick={() => setEditingDish(null)}>
                                  Cancel
                                </Button>
                              </div>
                            </Form>
                          ) : (
                            <>
                              <Card.Title>{dish.name}</Card.Title>
                              <Card.Text>{dish.description}</Card.Text>
                              <Card.Text className="text-primary fw-bold">
                                ${dish.price}
                              </Card.Text>
                              <Card.Text className="text-muted">
                                Category: {dish.category}
                              </Card.Text>
                              <Button
                                variant="primary"
                                onClick={() => handleEditClick(dish)}
                              >
                                Edit
                              </Button>
                            </>
                          )}
                        </Card.Body>
                      </Card>
                    </Col>
                  ))}
                </Row>
              ) : (
                <Alert variant="info">No dishes available</Alert>
              )}
            </Col>
          </Row>
        </Tab>
      </Tabs>

      <Modal show={showCustomerProfileModal} onHide={handleCloseCustomerProfileModal} size="lg" centered>
        <Modal.Header closeButton>
          <Modal.Title>Customer Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {customerProfiles[selectedCustomer] ? (
            <div>
              <p><b>Name:</b> {customerProfiles[selectedCustomer].name}</p>
              <p><b>Email:</b> {customerProfiles[selectedCustomer].email}</p>
              {/* Add other customer profile details as needed */}
              {customerProfiles[selectedCustomer].profile_picture && (
                <img
                  src={customerProfiles[selectedCustomer].profile_picture}
                  alt="Customer Profile Picture"
                  style={{ maxWidth: '100px', maxHeight: '100px' }}
                />
              )}
            </div>
          ) : (
            <p>Loading customer profile...</p>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseCustomerProfileModal}>Close</Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}

export default RestaurantProfile;
