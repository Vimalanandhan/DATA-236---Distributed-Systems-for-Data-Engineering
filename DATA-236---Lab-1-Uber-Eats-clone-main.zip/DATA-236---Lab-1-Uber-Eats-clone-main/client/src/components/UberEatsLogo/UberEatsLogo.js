import React from 'react';
import uberEatsLogo from './UberEatsLogo.png'; // Correct import statement

const UberEatsLogo = ({onClick}) => { // Add onClick prop
  return (
    <div className="logo-wrapper" onClick={onClick}> {/*Added onClick handler*/}
      <img src={uberEatsLogo} alt="Uber Eats Logo" className="uber-eats-logo" />
    </div>
  );
};

export default UberEatsLogo;
