import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './Login.css';
import { useDispatch } from 'react-redux';
import { loginSuccess } from '../../store/slices/authSlice';
import { Button } from 'react-bootstrap';

const Login = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Ensure the API URL is properly formatted
      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const loginUrl = `${apiUrl}/auth/customer/login`;

      console.log('Making login request to:', loginUrl); // Debug log

      const response = await fetch(loginUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const data = await response.json();

        // Save token to localStorage
        localStorage.setItem('customerAuthToken', data.token);

        dispatch(loginSuccess({
          user: {
            id: data.id,
            name: data.name,
            email: data.email
          },
          token: data.token
        }));

        const deliveryAddress = localStorage.getItem('deliveryAddress');
        const navigationOptions = {};
        if (deliveryAddress) {
          console.log('Found delivery address:', deliveryAddress);
          navigationOptions.state = { deliveryAddress: deliveryAddress };
          localStorage.removeItem('deliveryAddress');
        }

        navigate('/home', navigationOptions);
      } else {
        const data = await response.json();
        setError(data.error || 'Login failed');
      }
    } catch (err) {
      console.error('Login failed:', err);
      if (err instanceof SyntaxError) {
        setError('Failed to process server response. Is the server running and configured correctly?');
      } else {
        setError('Network error occurred while trying to log in.');
      }
    }
  };

  return (
    <div className="login-container">
      <h2>Customer Login</h2>
      {error && <div className="error-message">{error}</div>}
      <form onSubmit={handleSubmit} className="login-form">
        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input
            type="password"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            required
          />
        </div>
        <div className="form-group">
          <Button variant="primary" type="submit" className="w-100">
            Login
          </Button>
        </div>
      </form>
      <div className="text-center mt-3">
        <p>Don't have an account? <Link to="/signup">Sign up</Link></p>
        <p className="mt-2">Are you a restaurant owner? <Link to="/restaurant/login">Restaurant Login</Link> | <Link to="/restaurant/signup">Add Restaurant</Link></p>
        <p className="mt-2"><Link to="/">Back to Home</Link></p>
      </div>
    </div>
  );
};

export default Login;
