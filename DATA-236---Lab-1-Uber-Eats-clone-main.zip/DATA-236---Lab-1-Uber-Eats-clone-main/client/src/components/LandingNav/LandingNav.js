import React from 'react';
import { useNavigate } from 'react-router-dom';
import './LandingNav.css';
import UberEatsLogo from '../UberEatsLogo/UberEatsLogo';

const LandingNav = () => {
  const navigate = useNavigate();

  return (
    <nav className="landing-nav">
      <div className="nav-left">
        <UberEatsLogo />
      </div>
      <div className="nav-right">
        <button onClick={() => navigate('/login')} className="nav-btn login-btn">
          Log in
        </button>
        <button onClick={() => navigate('/signup')} className="nav-btn signup-btn">
          Sign up
        </button>
        <button onClick={() => navigate('/restaurant/login')} className="nav-btn restaurant-btn">
          Restaurant Log in
        </button>
        <button onClick={() => navigate('/restaurant/signup')} className="nav-btn restaurant-btn">
          Add your restaurant
        </button>
      </div>
    </nav>
  );
};

export default LandingNav;