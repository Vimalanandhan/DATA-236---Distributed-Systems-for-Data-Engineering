import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import './RestaurantDetails.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useDispatch, useSelector } from 'react-redux';
import { addItem } from '../../store/slices/cartSlice';

// Move this function outside of the component.
const getCartItemCount = (itemId, cartItems) => {
    if (!cartItems || !Array.isArray(cartItems)) {
        return 0;
    }

    let count = 0;
    for (const item of cartItems) {
        if (item.id === itemId) {
            count++;
        }
    }
    return count;
};

const arrayBufferToBase64 = (buffer) => {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
};

const RestaurantDetails = () => {
    const { id } = useParams();
    const [restaurant, setRestaurant] = useState(null);
    const [menu, setMenu] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [showAddedToCartAlert, setShowAddedToCartAlert] = useState(false);
    const [alertItem, setAlertItem] = useState(null);
    const cartItems = useSelector((state) => state.cart.items);
    const auth = useSelector((state) => state.auth);

    useEffect(() => {
        const fetchRestaurantData = async () => {
            if (!id) return;
            try {
                setIsLoading(true);
                setError(null);
                console.log('Restaurant ID:', id);
                const restaurantResponse = await fetch(`/api/restaurants/${id}`);
                if (!restaurantResponse.ok) {
                    throw new Error('Failed to fetch restaurant details');
                }
                const restaurantData = await restaurantResponse.json();
                console.log('Restaurant data:', restaurantData);
                const restaurantDetails = restaurantData;
                console.log('Restaurant details:', restaurantDetails);
                if (restaurantDetails) {
                    setRestaurant(restaurantDetails);
                    const dishesResponse = await fetch(`/api/restaurants/${restaurantDetails._id}/menu`);
                    if (!dishesResponse.ok) {
                        throw new Error('Failed to fetch menu items');
                    }
                    const dishesData = await dishesResponse.json();
                    setMenu(dishesData);
                }
            } catch (error) {
                console.error('Error fetching restaurant data:', error);
                setError(error.message);
            } finally {
                setIsLoading(false);
            }
        };

        if (id) {
            fetchRestaurantData();
        }
    }, [id]);

    const handleAddToCart = (item) => {
        dispatch(addItem({ ...item, restaurant_id: restaurant._id }));
        console.log("Item added to cart:", item);
        setAlertItem(item);
        setShowAddedToCartAlert(true);
        setTimeout(() => {
            setShowAddedToCartAlert(false);
            setAlertItem(null);
        }, 500);
    };

    const handleClose = () => {
        navigate(-1);
    };

    const handleViewCart = () => {
        navigate('/cart');
    };

    // Early returns inside the component
    if (isLoading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    if (!restaurant) {
        return <div>Restaurant not found</div>;
    }

    console.log("restaurant.image:", restaurant.image);
    const imageSource = restaurant.image ? `data:image/jpeg;base64,${arrayBufferToBase64(restaurant.image.data)}` : null;

    return (
        <div className="restaurant-details container">
            {restaurant && (
                <>
                    <div className="restaurant-header bg-light p-4 mb-4 rounded">
                        {imageSource && (
                            <img
                                src={imageSource}
                                alt={restaurant.name}
                                className="img-fluid rounded mb-3"
                            />
                        )}
                        <h1>{restaurant.name}</h1>
                        <p>{restaurant.description}</p>
                        <div className="restaurant-info">
                            <p>Location: {restaurant.location}</p>
                            <p>Contact: {restaurant.contact_info}</p>
                        </div>
                    </div>

                    <div className="menu-section">
                        <h2>Menu</h2>
                        <div className="row row-cols-1 row-cols-md-3 g-4">
                            {menu.map((item) => (
                                <div key={item._id} className="col">
                                    <div className="card h-100">
                                        {item.image && (
                                            <img
                                                src={`data:image/jpeg;base64,${item.image}`}
                                                alt={item.name}
                                                className="card-img-top"
                                            />
                                        )}
                                        <div className="card-body">
                                            <h5 className="card-title">{item.name}</h5>
                                            <p className="card-text">{item.description}</p>
                                            <p className="card-text">${item.price}</p>
                                            <button
                                                className="btn btn-primary"
                                                onClick={() => handleAddToCart(item)}
                                            >
                                                Add to Cart
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {showAddedToCartAlert && (
                        <div className="alert alert-success alert-dismissible fade show" role="alert">
                            {alertItem.name} added to cart!
                            <button
                                type="button"
                                className="btn-close"
                                onClick={() => setShowAddedToCartAlert(false)}
                            ></button>
                        </div>
                    )}

                    <div className="action-buttons">
                        <button className="btn btn-secondary" onClick={handleClose}>
                            Back
                        </button>
                        <button className="btn btn-primary" onClick={handleViewCart}>
                            View Cart ({cartItems.length})
                        </button>
                        {auth.user && auth.user.role === 'restaurant' ? (
                            <Link to="/restaurant/dashboard" className="btn btn-info">
                                Go to Dashboard
                            </Link>
                        ) : (
                            <Link to="/home" className="btn btn-info">
                                Back to Home
                            </Link>
                        )}
                    </div>
                </>
            )}
        </div>
    );
};

export default RestaurantDetails;
