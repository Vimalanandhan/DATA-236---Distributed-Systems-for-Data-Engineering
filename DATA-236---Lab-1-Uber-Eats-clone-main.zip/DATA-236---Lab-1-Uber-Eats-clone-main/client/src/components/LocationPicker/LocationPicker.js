import React, { useState } from 'react';
import './LocationPicker.css';

const LocationPicker = ({ location, onLocationChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const recentLocations = [
    'Home - 123 Main St, San Jose',
    'Work - 456 Office Ave, San Jose',
    'SJSU - 1 Washington Sq, San Jose'
  ];

  const getCurrentLocation = () => {
    setLoading(true);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          onLocationChange(`Current Location (${position.coords.latitude.toFixed(2)}, ${position.coords.longitude.toFixed(2)})`);
          setIsOpen(false);
          setLoading(false);
        },
        () => {
          setLoading(false);
        }
      );
    }
  };

  return (
    <div className="location-picker">
      <button 
        className="location-button"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="location-icon">📍</span>
        <span className="location-text">{location || 'Select location'}</span>
      </button>

      {isOpen && (
        <div className="location-dropdown">
          <div className="dropdown-header">
            <h3>Select a location</h3>
            <button onClick={() => setIsOpen(false)} className="close-button">×</button>
          </div>
          
          <div className="search-box">
            <input
              type="text"
              placeholder="Enter delivery address"
              value={location}
              onChange={(e) => onLocationChange(e.target.value)}
            />
          </div>

          <button 
            className="current-location-btn"
            onClick={getCurrentLocation}
            disabled={loading}
          >
            <span>📱</span>
            {loading ? 'Getting location...' : 'Use current location'}
          </button>

          <div className="recent-locations">
            <h4>Recent Locations</h4>
            {recentLocations.map((loc, index) => (
              <button
                key={index}
                className="location-option"
                onClick={() => {
                  onLocationChange(loc);
                  setIsOpen(false);
                }}
              >
                <span>📍</span> {loc}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default LocationPicker;