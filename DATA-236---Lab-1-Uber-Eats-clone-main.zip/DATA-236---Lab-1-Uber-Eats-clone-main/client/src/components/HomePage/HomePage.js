import React, { useState, useEffect, useCallback } from 'react';
import { Button, Alert } from 'react-bootstrap';
import RestaurantList from '../RestaurantList/RestaurantList';
import FilterBar from '../FilterBar/FilterBar';
import Cart from '../CartButton/Cart';
import './HomePage.css';
import UberEatsLogo from '../UberEatsLogo/UberEatsLogo';
import RestaurantDetails from '../RestaurantDetails/RestaurantDetails';
import { useNavigate, useLocation } from 'react-router-dom';
import { FaClipboardList, FaUser, FaHeart, FaRegHeart, FaSearch, FaMapMarkerAlt, FaCheck, FaTimes } from 'react-icons/fa';
import { useDispatch, useSelector } from 'react-redux';
import { fetchRestaurants, selectRestaurants, selectRestaurantLoading, selectRestaurantError } from '../../store/slices/restaurantSlice';
import { logout as logoutAction } from '../../store/slices/authSlice';

const HomePage = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [cartItems, setCartItems] = useState([]);
  const [filters, setFilters] = useState({
    cuisine: 'all',
    priceRange: 'all'
  });
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const [localError, setLocalError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredRestaurants, setFilteredRestaurants] = useState([]);
  const error = useSelector(selectRestaurantError);
  const navigate = useNavigate();
  const location = useLocation();

  // Address state
  const [displayAddress, setDisplayAddress] = useState('');
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [editableAddress, setEditableAddress] = useState('');

  // Auth state from Redux
  const { isAuthenticated, user, token } = useSelector(state => state.auth);

  // Favorites state
  const [favoriteIds, setFavoriteIds] = useState(new Set());
  const [loadingFavorites, setLoadingFavorites] = useState(false);

  // Effect to get initial address from location state or localStorage
  useEffect(() => {
    let initialAddress = '';
    if (location.state?.deliveryAddress) {
      console.log('HomePage received address from location:', location.state.deliveryAddress);
      initialAddress = location.state.deliveryAddress;
      // Optional: Clear location state
      // navigate(location.pathname, { replace: true, state: {} }); 
    } else {
      // Fallback: Check localStorage if not in location state
      const storedAddress = localStorage.getItem('deliveryAddress');
      if (storedAddress) {
        console.log('HomePage received address from localStorage:', storedAddress);
        initialAddress = storedAddress;
      } else {
        initialAddress = 'Set Location'; // Default placeholder
      }
    }
    setDisplayAddress(initialAddress);
    setEditableAddress(initialAddress === 'Set Location' ? '' : initialAddress); // Pre-fill edit input

  }, [location.state]);

  // Redux hooks
  const dispatch = useDispatch();
  const restaurants = useSelector(selectRestaurants);
  const loading = useSelector(selectRestaurantLoading);

  const categories = [
    "All", "Italian", "Chinese", "Japanese", "Indian",
    "Mexican", "American", "Thai", "Mediterranean"
  ];

  // Initial fetch on component mount
  useEffect(() => {
    dispatch(fetchRestaurants());
  }, [dispatch]);

  // Fetch favorites
  useEffect(() => {
    const fetchFavorites = async () => {
      if (isAuthenticated && token) {
        setLoadingFavorites(true);
        try {
          const response = await fetch('/api/favorites', {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          if (response.ok) {
            const favoriteRestaurants = await response.json();
            // Store only the IDs for quick lookup
            setFavoriteIds(new Set(favoriteRestaurants.map(fav => fav._id)));
          } else {
            console.error('Failed to fetch favorites:', response.status);
            // Handle error appropriately
          }
        } catch (err) {
          console.error('Error fetching favorites:', err);
          // Handle error appropriately
        } finally {
          setLoadingFavorites(false);
        }
      } else {
        setFavoriteIds(new Set()); // Clear favorites if not authenticated
      }
    };

    fetchFavorites();
  }, [isAuthenticated, token]);

  // Debounced search effect
  useEffect(() => {
    const timer = setTimeout(() => {
      let filtered = [...restaurants];
      console.log('Initial restaurants:', filtered);
      console.log('Current filters:', filters);
      console.log('Selected category:', selectedCategory);

      // Apply search query filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        filtered = filtered.filter(restaurant => {
          if (!restaurant) return false;

          const name = restaurant.name || '';
          const cuisine = restaurant.cuisine || '';
          const description = restaurant.description || '';

          return name.toLowerCase().includes(query) ||
            cuisine.toLowerCase().includes(query) ||
            description.toLowerCase().includes(query);
        });
      }

      // Apply cuisine filter
      if (filters.cuisine && filters.cuisine !== 'all') {
        console.log('Applying cuisine filter:', filters.cuisine);
        filtered = filtered.filter(restaurant => {
          console.log('Checking restaurant:', restaurant.name, 'cuisine:', restaurant.cuisine);
          return restaurant.cuisine === filters.cuisine;
        });
        console.log('After cuisine filter:', filtered);
      }

      // Apply category filter independently
      if (selectedCategory !== 'all') {
        console.log('Applying category filter:', selectedCategory);
        filtered = filtered.filter(restaurant => {
          console.log('Checking restaurant:', restaurant.name, 'cuisine:', restaurant.cuisine);
          return restaurant.cuisine === selectedCategory;
        });
        console.log('After category filter:', filtered);
      }

      console.log('Final filtered restaurants:', filtered);
      setFilteredRestaurants(filtered);
    }, 300); // 300ms debounce

    return () => clearTimeout(timer);
  }, [searchQuery, restaurants, selectedCategory, filters]);

  const handleCategoryChange = (category) => {
    console.log('Category changed to:', category);
    setSelectedCategory(category);
  };

  const handleFilterChange = (newFilters) => {
    console.log('Filter changed to:', newFilters);
    setFilters(newFilters);
  };

  const handleRestaurantClick = (restaurantId) => {
    navigate(`/restaurant/${restaurantId}`);
  };

  const handleClose = () => {
    setSelectedRestaurant(null);
  };

  const handleViewCart = () => {
    navigate('/cart');
  };

  const handleFavoritesClick = () => {
    navigate('/favorites');
  };

  const handleLogout = async () => {
    setLocalError(null);
    try {
      // 1. Attempt backend logout to clear HttpOnly cookie
      const backendLogoutUrl = '/api/auth/customer/logout';
      const customerToken = localStorage.getItem('customerAuthToken'); // Get token for Authorization header

      // Prepare headers. Only send Authorization if token exists.
      const headers = {};
      if (customerToken) {
        headers['Authorization'] = `Bearer ${customerToken}`;
      }

      const response = await fetch(backendLogoutUrl, {
        method: 'POST',
        headers: headers,
        // credentials: 'include' // Might not be needed if using Authorization header, but include if server expects cookies
      });

      if (!response.ok) {
        // Log error but proceed with client-side cleanup regardless
        console.error('Backend logout failed:', response.status, await response.text());
        // Optionally: setLocalError based on backend failure
      } else {
        console.log('Backend logout successful.');
      }

    } catch (error) {
      // Log fetch error but proceed with client-side cleanup
      console.error('Error calling backend logout:', error);
      // Optionally: setLocalError based on fetch failure
    } finally {
      // 2. Always clear localStorage
      localStorage.removeItem('customerAuthToken');
      console.log('Removed customerAuthToken from localStorage.');

      // 3. Always dispatch Redux logout action
      dispatch(logoutAction());
      console.log('Dispatched Redux logout action.');

      // 4. Always navigate user
      navigate('/'); // Navigate to landing page
    }
  };

  // --- Replace simple image handling with the more robust function ---
  const getImageUrl = (restaurant) => {
    const fallbackImageUrl = 'https://iadairport.com/images/default-resturant.jpg';

    if (!restaurant || !restaurant.image) {
      console.log(`Using fallback for restaurant ${restaurant?._id || 'unknown'}`);
      return fallbackImageUrl;
    }

    // Assuming image is stored as base64 string in the database
    // Check if it already has the data URI scheme
    if (restaurant.image.startsWith('data:image')) {
      return restaurant.image;
    }

    // Check if it looks like a base64 string (basic check)
    // This might need refinement based on actual data format
    if (restaurant.image.length > 100 && !restaurant.image.startsWith('http')) {
      // Prepend the necessary prefix for base64 images
      return `data:image/jpeg;base64,${restaurant.image}`;
    }

    // If it's a URL (though unlikely with current setup)
    if (restaurant.image.startsWith('http')) {
      return restaurant.image;
    }

    // If none of the above, use fallback
    console.log(`Using fallback for restaurant ${restaurant._id} - unrecognized image format`);
    return fallbackImageUrl;
  };

  // --- Address Edit Handlers --- 
  const handleEditAddressClick = () => {
    setEditableAddress(displayAddress === 'Set Location' ? '' : displayAddress); // Use current display value
    setIsEditingAddress(true);
  };

  const handleSaveAddress = () => {
    if (editableAddress.trim()) {
      setDisplayAddress(editableAddress);
      localStorage.setItem('deliveryAddress', editableAddress); // Persist change
      setIsEditingAddress(false);
      // TODO: Maybe trigger a re-fetch of restaurants based on new location?
      console.log('Saved new address:', editableAddress);
    } else {
      // Handle empty address save attempt (e.g., show error or revert)
      console.warn('Attempted to save empty address.');
      setDisplayAddress('Set Location'); // Revert to placeholder
      localStorage.removeItem('deliveryAddress');
      setIsEditingAddress(false);
    }
  };

  const handleCancelEditAddress = () => {
    setIsEditingAddress(false);
    // Optionally revert editableAddress state if needed
    // setEditableAddress(displayAddress);
  };
  // -----------------------------

  // --- Toggle Favorite Handler --- 
  const handleToggleFavorite = async (restaurantId, isCurrentlyFavorited) => {
    console.log('HomePage - handleToggleFavorite - Auth Check:', { isAuthenticated, userToken: token });
    if (!isAuthenticated || !token) {
      navigate('/login');
      return;
    }

    const method = isCurrentlyFavorited ? 'DELETE' : 'POST';
    const url = isCurrentlyFavorited ? `/api/favorites/${restaurantId}` : '/api/favorites';
    const body = isCurrentlyFavorited ? null : JSON.stringify({ restaurant_id: restaurantId });
    const headers = {
      'Authorization': `Bearer ${token}`,
      ...(body && { 'Content-Type': 'application/json' })
    };

    // Optimistic UI update
    const originalFavorites = new Set(favoriteIds);
    setFavoriteIds(prev => {
      const newSet = new Set(prev);
      if (isCurrentlyFavorited) {
        newSet.delete(restaurantId);
      } else {
        newSet.add(restaurantId);
      }
      return newSet;
    });

    try {
      const response = await fetch(url, { method, headers, body });

      if (!response.ok) {
        console.error('Failed to toggle favorite:', response.status);
        // Revert optimistic update on failure
        setFavoriteIds(originalFavorites);
        alert('Failed to update favorites. Please try again.');
      } else {
        console.log('Favorite toggled successfully for:', restaurantId);
        // Optional: Refetch favorites for consistency, though optimistic update handles UI
        // fetchFavorites(); 
      }
    } catch (err) {
      console.error('Error toggling favorite:', err);
      // Revert optimistic update on failure
      setFavoriteIds(originalFavorites);
      alert('An error occurred. Please try again.');
    }
  };
  // -----------------------------

  return (
    <div className="home-container">
      <div className="header-section">
        <div className="top-bar">
          <div className="left-section">
            <div className="logo-wrapper" onClick={() => window.location.href = '/'}>
              <UberEatsLogo />
            </div>
          </div>
          <div className="middle-section">
            <div className="search-location-wrapper">
              {isEditingAddress ? (
                <div className="address-edit-container">
                  <input
                    type="text"
                    value={editableAddress}
                    onChange={(e) => setEditableAddress(e.target.value)}
                    placeholder="Enter delivery address"
                    className="address-edit-input"
                    autoFocus
                  />
                  <button onClick={handleSaveAddress} className="address-edit-btn save"><FaCheck /></button>
                  <button onClick={handleCancelEditAddress} className="address-edit-btn cancel"><FaTimes /></button>
                </div>
              ) : (
                <button onClick={handleEditAddressClick} className="location-display-button">
                  <FaMapMarkerAlt />
                  <span>{displayAddress || 'Set Location'}</span>
                </button>
              )}
              <div className="search-form">
                <input
                  type="text"
                  className="search-input"
                  placeholder="Search restaurants..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>
          <div className="right-section d-flex align-items-center">
            <Cart itemCount={cartItems.length} />
            {(error || localError) && <Alert variant="danger">{error || localError}</Alert>}
            <Button
              variant="primary"
              onClick={() => navigate('/customer/orders')}
              className="ms-3 custom-button"
            >
              <FaClipboardList className="me-1" /> Orders
            </Button>
            <Button
              variant="primary"
              onClick={handleFavoritesClick}
              className="ms-3 custom-button"
            >
              <FaHeart className="me-1" />
            </Button>
            <Button
              variant="primary"
              onClick={() => navigate('/profile')}
              className="ms-3 custom-button"
            >
              <FaUser className="me-1" />
            </Button>
            <Button variant="danger" onClick={handleLogout} className="ms-3">
              Sign Out
            </Button>
          </div>
        </div>
        <div className="categories-wrapper">
          <div className="categories-scroll">
            {categories.map((category, index) => (
              <button
                key={index}
                className={`category-btn ${selectedCategory === category ? 'active' : ''}`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>
      <FilterBar
        filters={filters}
        onFilterChange={handleFilterChange}
      />
      <div className="content-section">
        <div className="restaurants-section">
          <h2>Featured Restaurants</h2>
          {loading || loadingFavorites ? (
            <div className="loading">Loading...</div>
          ) : error ? (
            <div className="error-message">{error}</div>
          ) : filteredRestaurants.length === 0 ? (
            <div className="no-restaurants">
              {searchQuery ? 'No restaurants found matching your search' : 'No restaurants available'}
            </div>
          ) : (
            <div className="restaurant-grid">
              {filteredRestaurants.map((restaurant) => {
                // Log the restaurant object here
                console.log('Rendering restaurant:', restaurant);
                const isFavorited = favoriteIds.has(restaurant._id);
                return (
                  <div
                    key={restaurant._id}
                    className="restaurant-card"
                    onClick={() => handleRestaurantClick(restaurant._id)}
                  >
                    <div className="restaurant-image-container">
                      <img
                        src={getImageUrl(restaurant)}
                        alt={restaurant.name || 'Restaurant'}
                        className="restaurant-image"
                        onError={(e) => {
                          e.target.onerror = null;
                          e.target.src = 'https://via.placeholder.com/300x200';
                        }}
                      />
                      <div className="restaurant-cuisine-badge">
                        {restaurant.cuisine || 'Cuisine not specified'}
                      </div>
                    </div>
                    <div className="restaurant-info">
                      <h3>{restaurant.name || 'Unnamed Restaurant'}</h3>
                      <div className="restaurant-meta">
                        <span className="delivery-time">🕒 {restaurant.timings || 'N/A'}</span>
                      </div>
                      <p className="restaurant-description">
                        {restaurant.description || 'No description available'}
                      </p>
                    </div>
                    <button
                      className={`favorite-btn ${isFavorited ? 'favorited' : ''}`}
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent card click
                        handleToggleFavorite(restaurant._id, isFavorited);
                      }}
                    >
                      {isFavorited ? <FaHeart /> : <FaRegHeart />}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {selectedRestaurant && (
        <RestaurantDetails
          restaurant={selectedRestaurant}
          onClose={handleClose}
          onViewCart={handleViewCart}
        />
      )}
    </div>
  );
};

export default HomePage;
