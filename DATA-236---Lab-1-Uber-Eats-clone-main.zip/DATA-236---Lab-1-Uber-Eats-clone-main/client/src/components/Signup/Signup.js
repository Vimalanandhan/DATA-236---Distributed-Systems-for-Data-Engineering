import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './Signup.css';
import { Button } from 'react-bootstrap';

const Signup = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    country: '',
    state: ''
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    let value = e.target.value;
    if (e.target.name === 'state') {
      value = value.toUpperCase().slice(0, 2);
    }
    setFormData({
      ...formData,
      [e.target.name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (formData.state.length !== 2) {
      setError('State must be 2 letters');
      return;
    }

    try {
      console.log('Form data:', formData);

      // Use standard API URL construction with fallback
      const apiUrl = process.env.REACT_APP_API_URL || '/api';
      const signupUrl = `${apiUrl}/auth/customer/signup`;

      const response = await fetch(signupUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          country: formData.country,
          state: formData.state
        })
      });

      const data = await response.json();

      if (response.ok) {
        console.log('Response data:', data);
        navigate('/login'); // Update navigation path
      } else {
        console.log('Response data:', data);
        setError(data.error || 'Signup failed');
      }
    } catch (err) {
      console.error('Signup failed:', err);
      if (err instanceof SyntaxError) {
        setError('Failed to process server response. Is the server running and configured correctly?');
      } else {
        setError('Network error occurred while trying to sign up.');
      }
    }
  };

  return (
    <div className="signup-container">
      <h2>Create Account</h2>
      {error && <div className="error-message">{error}</div>}
      <form onSubmit={handleSubmit} className="signup-form">
        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="confirmPassword">Confirm Password</label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="country">Country</label>
          <input
            type="text"
            id="country"
            name="country"
            value={formData.country}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="state">State (2 letters)</label>
          <input
            type="text"
            id="state"
            name="state"
            value={formData.state}
            onChange={handleChange}
            maxLength="2"
            placeholder="CA"
            required
          />
        </div>
        <div className="form-group">
          <Button variant="primary" type="submit" className="w-100">
            Sign Up
          </Button>
        </div>
        <div className="text-center mt-3">
          <p>Already have an account? <Link to="/login">Login</Link></p>
          <p className="mt-2">Are you a restaurant owner? <Link to="/restaurant/login">Restaurant Login</Link> | <Link to="/restaurant/signup">Add Restaurant</Link></p>
          <p className="mt-2"><Link to="/">Back to Home</Link></p>
        </div>
      </form>
    </div>
  );
};

export default Signup;
