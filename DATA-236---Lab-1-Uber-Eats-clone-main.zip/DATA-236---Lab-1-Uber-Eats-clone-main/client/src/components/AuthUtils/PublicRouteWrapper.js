import React from 'react';
import { useSelector } from 'react-redux'; // <-- Add back useSelector
import { Navigate } from 'react-router-dom';

/**
 * A wrapper for public routes (like LandingPage, Login, Signup).
 * If the user is already authenticated according to the Redux state,
 * it redirects them to the main app page (/home).
 * Otherwise, it renders the intended public route component.
 */
const PublicRouteWrapper = ({ children }) => {
    // Rely solely on the Redux authentication state
    const isAuthenticated = useSelector(state => state.auth.isAuthenticated);
    // const customerToken = localStorage.getItem('customerAuthToken'); // <-- Remove localStorage check
    // const isCustomerAuthenticated = !!customerToken;

    console.log(
        '[PublicRouteWrapper] Checking auth. Redux IsAuthenticated:',
        isAuthenticated,
        '| Redirecting:',
        isAuthenticated
    );

    if (isAuthenticated) {
        console.log('[PublicRouteWrapper] User authenticated via Redux, redirecting to /home');
        // Customer authenticated via Redux, redirect to home page
        return <Navigate to="/home" replace />;
    }

    // Customer not authenticated via Redux, render the requested public page
    return children;
};

export default PublicRouteWrapper; 