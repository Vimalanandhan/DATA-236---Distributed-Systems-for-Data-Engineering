import React, { useState } from 'react';

const AddDishForm = ({ onDishAdded }) => {
  const [dish, setDish] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    ingredients: '',
    image: null
  });
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(process.env.REACT_APP_API_URL + '/api/dishes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(dish)
      });

      if (response.ok) {
        setDish({
          name: '',
          description: '',
          price: '',
          category: '',
          ingredients: '',
          image: null
        });
        onDishAdded();
      } else {
        setError('Failed to add dish');
      }
    } catch (err) {
      setError('Failed to add dish');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="add-dish-form">
      <h3>Add New Dish</h3>
      {error && <div className="error">{error}</div>}
      <div className="form-group">
        <label>Name</label>
        <input
          type="text"
          value={dish.name}
          onChange={(e) => setDish({ ...dish, name: e.target.value })}
          required
        />
      </div>
      <div className="form-group">
        <label>Description</label>
        <textarea
          value={dish.description}
          onChange={(e) => setDish({ ...dish, description: e.target.value })}
          required
        />
      </div>
      <div className="form-group">
        <label>Price</label>
        <input
          type="number"
          value={dish.price}
          onChange={(e) => setDish({ ...dish, price: e.target.value })}
          required
        />
      </div>
      <div className="form-group">
        <label>Category</label>
        <select
          value={dish.category}
          onChange={(e) => setDish({ ...dish, category: e.target.value })}
          required
        >
          <option value="">Select category</option>
          <option value="Appetizer">Appetizer</option>
          <option value="Salad">Salad</option>
          <option value="Main Course">Main Course</option>
          <option value="Dessert">Dessert</option>
        </select>
      </div>
      <button type="submit" className="submit-btn">Add Dish</button>
    </form>
  );
};

export default AddDishForm;