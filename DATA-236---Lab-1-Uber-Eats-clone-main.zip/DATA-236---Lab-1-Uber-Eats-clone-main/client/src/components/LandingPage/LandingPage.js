import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaMapMarkerAlt, FaClock } from 'react-icons/fa'; // Assuming react-icons is installed
import { Dropdown } from 'react-bootstrap'; // Import Dropdown if using react-bootstrap
import './LandingPage.css';
import LandingNav from '../LandingNav/LandingNav'; // Import the LandingNav component

const LandingPage = () => {
  // --- Remove hooks related to redirect --- 
  const navigate = useNavigate(); // Keep useNavigate for the search form
  // const isAuthenticated = useSelector(state => state.auth.isAuthenticated);
  // console.log('[LandingPage] Rendering. isAuthenticated:', isAuthenticated);
  // ---------------------------------------

  // --- Remove redirect logic ---
  // if (isAuthenticated) {
  //   console.log('[LandingPage] User authenticated, rendering <Navigate> to /home');
  //   return <Navigate to="/home" replace />;
  // }
  // ---------------------------

  // Component state
  const [address, setAddress] = useState('');
  const [deliveryOption, setDeliveryOption] = useState('now');

  const handleSearch = (e) => {
    e.preventDefault();
    console.log(`Searching for address: ${address}, Delivery: ${deliveryOption}`);
    if (address) {
      localStorage.setItem('deliveryAddress', address);
    } else {
      console.warn('Address field is empty.');
    }
    navigate('/login'); // Keep navigation for form submission
  };

  const handleScheduleClick = () => {
    console.log('Open scheduling modal/options...');
  };

  // Render the actual landing page content
  return (
    <div className="landing-container-new">
      <LandingNav /> {/* Render the LandingNav component here */}
      <div className="landing-content-new">
        <h1>Order delivery near you</h1>
        <form onSubmit={handleSearch} className="address-form-new">
          <div className="input-wrapper">
            <FaMapMarkerAlt className="input-icon" />
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Enter delivery address"
              className="address-input-new"
              required
            // Add attributes for autocomplete if using a library
            />
            {/* Add loading/suggestion display here if implementing autocomplete */}
          </div>
          {/* --- FIX: Delivery Time Dropdown/Button --- */}
          {/* Using simple button for now, replace with Dropdown if needed */}
          <button
            type="button"
            className="delivery-time-btn"
            onClick={deliveryOption === 'now' ? handleScheduleClick : () => setDeliveryOption('now')}
          >
            <FaClock className="input-icon" />
            <span>{deliveryOption === 'now' ? 'Deliver now' : 'Schedule'}</span>
            <span className="dropdown-arrow">▼</span>
          </button>
          {/* --------------------------------------- */}
          <button type="submit" className="search-button-new">
            Search here
          </button>
        </form>
        <div className="signin-options">
          <Link to="/login">Or Sign In</Link>
          <span className="link-separator">|</span>
          <Link to="/restaurant/login">Restaurant Sign In</Link>
          <span className="link-separator">|</span>
          <Link to="/restaurant/signup">Add your restaurant</Link>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
