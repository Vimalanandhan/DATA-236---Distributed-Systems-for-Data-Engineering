import React from 'react';
import './FilterBar.css';

const FilterBar = ({ onFilterChange, filters }) => {
  const handleFilterChange = (type, value) => {
    console.log('FilterBar: Filter changed:', type, value);
    onFilterChange(prevFilters => {
      const newFilters = {
        ...prevFilters,
        [type]: value
      };
      console.log('FilterBar: New filters:', newFilters);
      return newFilters;
    });
  };

  return (
    <div className="filter-bar">
      <div className="filter-label">Filter by Cuisine:</div>
      <select
        value={filters.cuisine}
        onChange={(e) => handleFilterChange('cuisine', e.target.value)}
        className="filter-select"
      >
        <option value="all">All Cuisines</option>
        <option value="Italian">Italian</option>
        <option value="Chinese">Chinese</option>
        <option value="Japanese">Japanese</option>
        <option value="Indian">Indian</option>
        <option value="Mexican">Mexican</option>
        <option value="American">American</option>
        <option value="Thai">Thai</option>
        <option value="Mediterranean">Mediterranean</option>
      </select>
    </div>
  );
};

export default FilterBar;