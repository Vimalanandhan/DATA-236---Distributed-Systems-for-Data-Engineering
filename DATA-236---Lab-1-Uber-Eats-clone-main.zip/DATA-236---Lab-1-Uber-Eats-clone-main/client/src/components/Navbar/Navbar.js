import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaBars, FaTimes, FaUserCircle, FaStore, FaPlus, FaSignOutAlt, FaApple, FaGooglePlay, FaHome, FaBoxOpen, FaHeart, FaUser } from 'react-icons/fa'; // Import icons
import './Navbar.css'; // We will create/update this CSS

// Reusable NavItem component
const NavItem = ({ to, icon, text, isExpanded, onClick }) => (
  <Link to={to} className="nav-item-new" onClick={onClick}>
    {icon && <span className="nav-icon">{icon}</span>}
    {isExpanded && <span className="nav-text">{text}</span>}
  </Link>
);

const Navbar = ({ isExpanded, setIsExpanded, isCustomerAuth, isRestaurantAuth, handleSignOut }) => {
  const navigate = useNavigate();

  // Define link sets based on auth status
  const customerLinks = [
    { path: '/home', icon: <FaHome />, text: 'Home' },
    { path: '/customer/orders', icon: <FaBoxOpen />, text: 'Orders' },
    { path: '/favorites', icon: <FaHeart />, text: 'Favorites' },
    { path: '/profile', icon: <FaUser />, text: 'Profile' }
  ];

  const restaurantLinks = [
    { path: '/restaurant/profile', icon: <FaStore />, text: 'Restaurant Dashboard' },
    // Add other restaurant-specific links here if needed
  ];

  const loggedOutLinks = [
    { path: '/login', icon: <FaUserCircle />, text: 'Customer Login / Sign Up' }, // Combined for simplicity
    { path: '/restaurant/login', icon: <FaStore />, text: 'Restaurant Login' },
    { path: '/restaurant/signup', icon: <FaPlus />, text: 'Add your restaurant' },
    // { path: '/delivery-signup', icon: <FaMotorcycle />, text: 'Sign up to deliver' }, // Keep commented or add
    // --------------------------------
  ];

  return (
    <div className={`sidebar-new ${isExpanded ? 'expanded' : 'collapsed'}`}>
      {/* Top section (Hamburger & Logo) - Visible in both states? Logo might hide when collapsed */}
      <div className="sidebar-top">
        <button onClick={() => setIsExpanded(!isExpanded)} className="hamburger-btn-new">
          {isExpanded ? <FaTimes /> : <FaBars />}
        </button>
        {isExpanded && (
          <Link to="/" className="sidebar-logo">
            {/* Replace with your actual logo component or img tag */}
            Uber Eats
          </Link>
        )}
      </div>

      {/* Main Navigation Links - Conditionally Rendered */}
      <nav className="sidebar-nav">
        {isCustomerAuth ? (
          customerLinks.map(item => <NavItem key={item.path} {...item} isExpanded={isExpanded} />)
        ) : isRestaurantAuth ? (
          restaurantLinks.map(item => <NavItem key={item.path} {...item} isExpanded={isExpanded} />)
        ) : (
          // Render loggedOutLinks which now include login/signup
          loggedOutLinks.map(item => <NavItem key={item.path} {...item} isExpanded={isExpanded} />)
        )}
        {/* Sign Out button only shown when logged in */}
        {(isCustomerAuth || isRestaurantAuth) && (
          <button onClick={handleSignOut} className={`sign-out-btn-new ${!isExpanded ? 'icon-only' : ''}`}>
            <FaSignOutAlt />
            {isExpanded && <span>Sign Out</span>}
          </button>
        )}
      </nav>

      {/* Bottom App Download Section - Visible when expanded */}
      {isExpanded && (
        <div className="sidebar-bottom">
          <div className="app-download">
            <p>There's more to love in the app.</p>
            <div className="app-links">
              {/* Replace with actual links/buttons */}
              <button className="app-link-btn"><FaApple /> iPhone</button>
              <button className="app-link-btn"><FaGooglePlay /> Android</button>
            </div>
          </div>
          {/* Optional: Repeating logo at bottom */}
          {/* <div className="sidebar-logo-bottom">Uber Eats</div> */}
        </div>
      )}
    </div>
  );
};

export default Navbar;
