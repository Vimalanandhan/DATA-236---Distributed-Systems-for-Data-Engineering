import React, { useState } from 'react';

const DishList = ({ dishes, onDishUpdated }) => {
  const [error, setError] = useState('');

  const handleEditDish = async (dish) => {
    try {
      // Navigate to edit form or show modal
      onDishUpdated(dish);
    } catch (err) {
      setError('Failed to edit dish');
    }
  };

  const handleDeleteDish = async (dishId) => {
    try {
      const response = await fetch(`/api/dishes/${dishId}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (response.ok) {
        onDishUpdated();
      } else {
        setError('Failed to delete dish');
      }
    } catch (err) {
      setError('Failed to delete dish');
    }
  };

  return (
    <div className="dish-list">
      <h3>Current Dishes</h3>
      {error && <div className="error">{error}</div>}
      <div className="dishes-grid">
        {dishes.map(dish => (
          <div key={dish.id} className="dish-card">
            <img src={dish.image || 'default-dish.jpg'} alt={dish.name} />
            <div className="dish-info">
              <h4>{dish.name}</h4>
              <p>{dish.description}</p>
              <p className="price">${dish.price}</p>
              <p className="category">{dish.category}</p>
              <div className="dish-actions">
                <button onClick={() => handleEditDish(dish)}>Edit</button>
                <button onClick={() => handleDeleteDish(dish.id)} className="delete">Delete</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DishList;