import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import RestaurantCard from '../RestaurantCard/RestaurantCard';
import './RestaurantList.css';
import { fetchRestaurants, selectRestaurants, selectRestaurantLoading, selectRestaurantError } from '../../store/slices/restaurantSlice';

const RestaurantList = () => {
  const dispatch = useDispatch();
  const restaurants = useSelector(selectRestaurants);
  const loading = useSelector(selectRestaurantLoading);
  const error = useSelector(selectRestaurantError);

  useEffect(() => {
    dispatch(fetchRestaurants());
  }, [dispatch]);

  if (loading) return <div className="loading">Loading restaurants...</div>;
  if (error) return <div className="error">Error: {error}</div>;
  if (!restaurants.length) return <div>No restaurants found</div>;

  return (
    <div className="restaurant-container">
      <h1>Available Restaurants</h1>
      <div className="restaurant-grid">
        {restaurants.map(restaurant => (
          <RestaurantCard
            key={restaurant._id}
            restaurant={{
              id: restaurant._id,
              name: restaurant.name,
              description: restaurant.description,
              location: restaurant.location,
              contact_info: restaurant.contact_info,
              image: restaurant.image,
              timings: restaurant.timings
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default RestaurantList;